import hashlib
import json
import os
import shutil
import subprocess
import threading
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import requests

from .paths import data_dir

CDN = "https://setup.rbxcdn.com"
VERSION_API = "https://clientsettingscdn.roblox.com/v2/client-version/WindowsPlayer"
RDD_URL = "https://rdd.weao.gg/?channel=LIVE&binaryType=WindowsPlayer&version={version}"
DEFAULT_VERSION = "version-f0ea5da9412f4e35"
EXE = "RobloxPlayerBeta.exe"
TIMEOUT = 30
CHUNK = 256 * 1024

FOLDERS = {
    "RobloxApp.zip": "",
    "shaders.zip": "shaders",
    "ssl.zip": "ssl",
    "WebView2.zip": "",
    "WebView2RuntimeInstaller.zip": "WebView2RuntimeInstaller",
    "content-avatar.zip": "content/avatar",
    "content-configs.zip": "content/configs",
    "content-fonts.zip": "content/fonts",
    "content-sky.zip": "content/sky",
    "content-sounds.zip": "content/sounds",
    "content-textures2.zip": "content/textures",
    "content-models.zip": "content/models",
    "content-platform-fonts.zip": "PlatformContent/pc/fonts",
    "content-platform-dictionaries.zip": "PlatformContent/pc/shared_compression_dictionaries",
    "content-terrain.zip": "PlatformContent/pc/terrain",
    "content-textures3.zip": "PlatformContent/pc/textures",
    "extracontent-luapackages.zip": "ExtraContent/LuaPackages",
    "extracontent-translations.zip": "ExtraContent/translations",
    "extracontent-models.zip": "ExtraContent/models",
    "extracontent-textures.zip": "ExtraContent/textures",
    "extracontent-places.zip": "ExtraContent/places",
}

APP_SETTINGS = (
    '<?xml version="1.0" encoding="UTF-8"?>\r\n'
    "<Settings>\r\n"
    "\t<ContentFolder>content</ContentFolder>\r\n"
    "\t<BaseUrl>http://www.roblox.com</BaseUrl>\r\n"
    "</Settings>\r\n"
)


class InstallError(Exception):
    pass


class Cancelled(Exception):
    pass


def roblox_dir():
    base = os.environ.get("LOCALAPPDATA")
    if not base:
        base = str(Path.home() / "AppData" / "Local")
    return Path(base) / "Roblox"


def versions_dir():
    return roblox_dir() / "Versions"


def record_file():
    return data_dir() / "installed.json"


def read_record():
    try:
        data = json.loads(record_file().read_text(encoding="utf-8"))
        return [v for v in data.get("versions", []) if isinstance(v, str)]
    except (OSError, ValueError):
        return []


def write_record(versions):
    record_file().write_text(json.dumps({"versions": versions}), encoding="utf-8")


def installed_versions():
    root = versions_dir()
    if not root.exists():
        return []
    found = []
    for path in root.iterdir():
        if path.is_dir() and (path / EXE).exists():
            found.append(path)
    found.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return found


def player_exe():
    versions = installed_versions()
    return versions[0] / EXE if versions else None


def is_installed():
    return bool(installed_versions())


def normalize_version(value):
    value = (value or "").strip()
    if not value:
        return DEFAULT_VERSION
    if not value.startswith("version-"):
        value = "version-" + value
    return value.lower()


def latest_version():
    try:
        response = requests.get(VERSION_API, timeout=TIMEOUT)
        version = response.json()["clientVersionUpload"]
    except Exception as error:
        raise InstallError("Could not look up the latest version") from error
    return normalize_version(version)


def base_url(channel):
    channel = (channel or "LIVE").strip()
    if channel.lower() in ("live", "zlive", ""):
        return CDN
    return f"{CDN}/channel/{channel.lower()}"


def parse_manifest(text):
    lines = [line.strip() for line in text.splitlines()]
    lines = [line for line in lines if line]
    if not lines or not lines[0].startswith("v"):
        raise InstallError("Unexpected manifest format")
    body = lines[1:]
    packages = []
    for index in range(0, len(body) - 3, 4):
        name, digest, packed, size = body[index:index + 4]
        try:
            packages.append({"name": name, "md5": digest.lower(), "packed": int(packed), "size": int(size)})
        except ValueError:
            raise InstallError("Corrupt manifest entry") from None
    if not packages:
        raise InstallError("Manifest has no packages")
    return packages


def fetch_manifest(version, channel):
    url = f"{base_url(channel)}/{version}-rbxPkgManifest.txt"
    try:
        response = requests.get(url, timeout=TIMEOUT)
    except requests.RequestException as error:
        raise InstallError("Could not reach the Roblox CDN") from error
    if response.status_code != 200:
        raise InstallError(f"Version not found ({response.status_code})")
    return parse_manifest(response.text)


def safe_extract(archive_path, target):
    target = Path(target).resolve()
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            name = info.filename.replace("\\", "/").lstrip("/")
            if not name or name.endswith("/"):
                continue
            destination = (target / name).resolve()
            if target != destination and target not in destination.parents:
                raise InstallError("Archive contains an unsafe path")
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, open(destination, "wb") as handle:
                shutil.copyfileobj(source, handle, CHUNK)


class Progress:
    def __init__(self, total, callback):
        self.total = max(1, total)
        self.done = 0
        self.callback = callback
        self.lock = threading.Lock()

    def add(self, amount, text):
        with self.lock:
            self.done += amount
            value = min(0.97, self.done / self.total)
        if self.callback:
            self.callback(value, text)


def download_package(url, expected_md5, path, progress, name, cancel):
    digest = hashlib.md5()
    try:
        response = requests.get(url, stream=True, timeout=TIMEOUT)
    except requests.RequestException as error:
        raise InstallError(f"Download failed: {name}") from error
    if response.status_code != 200:
        raise InstallError(f"Download failed: {name} ({response.status_code})")
    with open(path, "wb") as handle:
        for chunk in response.iter_content(CHUNK):
            if cancel.is_set():
                raise Cancelled()
            if not chunk:
                continue
            handle.write(chunk)
            digest.update(chunk)
            progress.add(len(chunk), f"Downloading {name}")
    if digest.hexdigest() != expected_md5:
        raise InstallError(f"Checksum mismatch: {name}")


def install(version, channel="LIVE", callback=None, cancel=None):
    if os.name != "nt":
        raise InstallError("Installing the Roblox player is only supported on Windows")
    cancel = cancel or threading.Event()
    version = normalize_version(version)
    if callback:
        callback(0.0, "Reading manifest")
    packages = fetch_manifest(version, channel)
    total = sum(p["packed"] for p in packages) or 1
    destination = versions_dir() / version
    work = data_dir() / "downloads" / version
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    progress = Progress(total, callback)
    base = base_url(channel)
    wanted = [p for p in packages if p["name"] in FOLDERS]
    if not any(p["name"] == "RobloxApp.zip" for p in wanted):
        raise InstallError("Manifest is missing the player package")
    try:
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = [
                pool.submit(
                    download_package,
                    f"{base}/{version}-{p['name']}",
                    p["md5"],
                    work / p["name"],
                    progress,
                    p["name"],
                    cancel,
                )
                for p in wanted
            ]
            for future in futures:
                future.result()
        if destination.exists():
            shutil.rmtree(destination, ignore_errors=True)
        destination.mkdir(parents=True, exist_ok=True)
        for index, package in enumerate(wanted, start=1):
            if cancel.is_set():
                raise Cancelled()
            if callback:
                callback(0.97 + 0.02 * index / len(wanted), f"Extracting {package['name']}")
            safe_extract(work / package["name"], destination / FOLDERS[package["name"]])
        (destination / "AppSettings.xml").write_text(APP_SETTINGS, encoding="utf-8")
        if not (destination / EXE).exists():
            raise InstallError("Player executable missing after extraction")
    except BaseException:
        shutil.rmtree(destination, ignore_errors=True)
        raise
    finally:
        shutil.rmtree(work, ignore_errors=True)
    record = read_record()
    if version not in record:
        record.append(version)
    write_record(record)
    if callback:
        callback(1.0, "Installed " + version)
    return version


def stop_roblox():
    if os.name != "nt":
        return
    for image in (EXE, "RobloxPlayerLauncher.exe", "RobloxCrashHandler.exe"):
        try:
            subprocess.run(
                ["taskkill", "/F", "/IM", image],
                capture_output=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except OSError:
            pass
    time.sleep(1.0)


def uninstall():
    stop_roblox()
    removed = 0
    failed = []
    root = versions_dir()
    if root.exists():
        for path in list(root.iterdir()):
            if not path.is_dir() or not path.name.startswith("version-"):
                continue
            shutil.rmtree(path, ignore_errors=True)
            if path.exists():
                failed.append(path.name)
            else:
                removed += 1
        try:
            root.rmdir()
        except OSError:
            pass
    try:
        roblox_dir().rmdir()
    except OSError:
        pass
    if not failed:
        write_record([])
    shutil.rmtree(data_dir() / "downloads", ignore_errors=True)
    return removed, failed
