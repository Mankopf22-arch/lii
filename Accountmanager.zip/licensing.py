import base64
import hashlib
import hmac
import json
import platform
import secrets
import uuid

import requests

from .paths import data_dir

SECRET = b"CHANGE-THIS-SECRET-BEFORE-YOU-SHIP"
PREFIX = "VIBE"
SERVER_URL = ""


def license_file():
    return data_dir() / "license.json"


def normalize(key):
    return "".join(str(key).split()).upper()


def _signature(payload):
    digest = hmac.new(SECRET, payload.encode(), hashlib.sha256).digest()
    return base64.b32encode(digest).decode().rstrip("=")[:10]


def generate_key():
    payload = base64.b32encode(secrets.token_bytes(8)).decode().rstrip("=")[:10]
    raw = payload + _signature(payload)
    return PREFIX + "-" + "-".join(raw[i:i + 5] for i in range(0, 20, 5))


def format_valid(key):
    parts = normalize(key).split("-")
    if len(parts) != 5 or parts[0] != PREFIX:
        return False
    if any(len(part) != 5 for part in parts[1:]):
        return False
    raw = "".join(parts[1:])
    return hmac.compare_digest(_signature(raw[:10]), raw[10:])


def hwid():
    seed = f"{platform.node()}-{uuid.getnode()}-{platform.machine()}"
    return hashlib.sha256(seed.encode()).hexdigest()[:24]


def masked(key):
    parts = normalize(key).split("-")
    if len(parts) != 5:
        return "-----"
    return "-".join(parts[:2] + ["*****"] * 3)


def _digest(key):
    return hashlib.sha256(normalize(key).encode()).hexdigest()


def verify(key):
    key = normalize(key)
    if not format_valid(key):
        return False, "Invalid license key"
    if SERVER_URL:
        try:
            response = requests.post(SERVER_URL, json={"key": key, "hwid": hwid()}, timeout=10)
            data = response.json()
        except Exception:
            return False, "License server is not reachable"
        if not data.get("valid"):
            return False, data.get("message", "License rejected")
    return True, "OK"


def info():
    try:
        return json.loads(license_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def activate(key):
    ok, message = verify(key)
    if not ok:
        return False, message
    payload = {"hash": _digest(key), "hwid": hwid(), "masked": masked(key)}
    license_file().write_text(json.dumps(payload), encoding="utf-8")
    return True, "License activated"


def is_activated():
    data = info()
    return bool(data) and data.get("hwid") == hwid()


def confirm(key):
    data = info()
    if not data:
        return False, "Run the setup first"
    if data.get("hwid") != hwid():
        return False, "This license belongs to another device"
    if not hmac.compare_digest(str(data.get("hash", "")), _digest(key)):
        return False, "Wrong license key"
    return verify(key)


def session_token():
    return hmac.new(SECRET, ("session-" + hwid()).encode(), hashlib.sha256).hexdigest()


def session_valid(token):
    return bool(token) and hmac.compare_digest(token, session_token())
