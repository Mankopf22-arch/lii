import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from vibes import licensing


def main():
    count = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 5
    for _ in range(count):
        print(licensing.generate_key())


if __name__ == "__main__":
    main()
