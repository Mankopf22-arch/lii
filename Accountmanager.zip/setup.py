import os
import subprocess
import sys
from importlib import metadata
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from vibes import console


def check_python():
    if sys.version_info < (3, 9):
        console.fail("Python 3.9 or newer is required")
        sys.exit(1)
    console.ok(f"Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
    try:
        __import__("tkinter")
    except ImportError:
        console.fail("Tkinter is missing. Reinstall Python and enable tcl/tk")
        sys.exit(1)
    console.ok("Tkinter available")


def package_name(spec):
    for separator in (">=", "==", "<=", ">", "<", "~="):
        spec = spec.split(separator)[0]
    return spec.strip()


def is_installed(spec):
    try:
        metadata.version(package_name(spec))
        return True
    except metadata.PackageNotFoundError:
        return False


def install_requirements():
    console.info("Installing requirements")
    packages = [
        line.strip()
        for line in (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    total = len(packages)
    for index, package in enumerate(packages, start=1):
        name = package_name(package)
        print(f"    [{index}/{total}] {name} ...", end=" ", flush=True)
        if is_installed(package):
            print("already installed")
            continue
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", package, "--disable-pip-version-check", "--quiet"],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print()
            console.fail(f"Could not install {name}")
            tail = (result.stderr or result.stdout).strip().splitlines()[-4:]
            for line in tail:
                print("      " + line)
            sys.exit(1)
        print("done")
    console.ok("All requirements installed")
    optional = ROOT / "optional.txt"
    if optional.exists():
        for package in optional.read_text(encoding="utf-8").split():
            name = package_name(package)
            print(f"    [optional] {name} ...", end=" ", flush=True)
            if is_installed(package):
                print("already installed")
                continue
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", package, "--disable-pip-version-check", "--quiet"],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                print("skipped")
                console.warn("Login window unavailable, manual login will use your browser instead")
            else:
                print("done")


def check_roblox():
    from vibes import installer, roblox

    if roblox.installed():
        console.ok("Roblox found")
        return
    console.warn("Roblox is not installed on this computer")
    if os.name != "nt":
        console.warn("Automatic Roblox install is only available on Windows")
        return
    version = installer.DEFAULT_VERSION
    while True:
        answer = console.ask("Press Enter to install Roblox now, or type S to skip")
        if answer.lower() == "s":
            console.warn("Skipped. You can install Roblox later from the Roblox tab")
            return
        console.info(f"Installing {version}")
        try:
            installer.install(version, "LIVE", console.progress)
        except installer.InstallError as error:
            console.progress_end()
            console.fail(str(error))
            continue
        console.progress_end()
        break
    console.ok("Roblox installed")


def activate_license():
    from vibes import licensing

    if licensing.is_activated():
        console.ok("License already activated on this device")
        answer = console.ask("Press Enter to continue or type N to enter a new key")
        if answer.lower() != "n":
            return
    for attempt in range(3):
        key = console.ask("Enter your license key")
        ok, message = licensing.activate(key)
        if ok:
            console.ok(message)
            return
        console.fail(message)
    console.fail("Too many failed attempts")
    sys.exit(1)


def start_manager():
    console.pause(1.2)
    target = str(ROOT / "vibes_manager.py")
    if os.name == "nt":
        subprocess.Popen(
            [sys.executable, target],
            creationflags=subprocess.CREATE_NEW_CONSOLE,
            cwd=str(ROOT),
        )
        sys.exit(0)
    os.execv(sys.executable, [sys.executable, target])


def main():
    console.enable()
    console.banner("Setup")
    check_python()
    install_requirements()
    print()
    check_roblox()
    print()
    activate_license()
    print()
    console.ok("Setup finished, starting Vibes Manager")
    start_manager()


if __name__ == "__main__":
    main()
