import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from vibes import licensing


def main():
    if not licensing.session_valid(os.environ.get("VIBES_SESSION", "")):
        sys.exit(1)
    from vibes.gui import run

    run()


if __name__ == "__main__":
    main()
