import io
import time
import traceback

import customtkinter as ctk
from PIL import Image, ImageDraw

from .icons import render
from .paths import data_dir

FONT = "Segoe UI"


def width_hint(dialog):
    return max(200, getattr(dialog, "dialog_width", 400) - 44)


def F(size=13, bold=False):
    return ctk.CTkFont(family=FONT, size=size, weight="bold" if bold else "normal")


def log_error():
    try:
        with open(data_dir() / "error.log", "a", encoding="utf-8") as handle:
            handle.write(time.strftime("%Y-%m-%d %H:%M:%S") + "\n" + traceback.format_exc() + "\n")
    except Exception:
        pass


def short(number):
    try:
        number = float(number)
    except (TypeError, ValueError):
        return "-"
    if number >= 1_000_000:
        return f"{number / 1_000_000:.1f}M"
    if number >= 1_000:
        return f"{number / 1_000:.1f}K"
    return str(int(number))


def circle_image(data, px):
    size = px * 2
    img = Image.open(io.BytesIO(data)).convert("RGBA").resize((size, size), Image.LANCZOS)
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)
    img.putalpha(mask)
    return img


def rounded_image(data, px, radius):
    size = px * 2
    img = Image.open(io.BytesIO(data)).convert("RGBA").resize((size, size), Image.LANCZOS)
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, size - 1, size - 1), radius=radius * 2, fill=255)
    img.putalpha(mask)
    return img


def placeholder_circle(px, background, foreground, glyph_name="user"):
    size = px * 2
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(img).ellipse((0, 0, size - 1, size - 1), fill=background)
    glyph = render(glyph_name, int(size * 0.55), foreground)
    offset = (size - glyph.size[0]) // 2
    img.alpha_composite(glyph, (offset, offset))
    return img


def placeholder_square(px, background, foreground, radius):
    size = px * 2
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(img).rounded_rectangle((0, 0, size - 1, size - 1), radius=radius * 2, fill=background)
    glyph = render("grid", int(size * 0.5), foreground)
    offset = (size - glyph.size[0]) // 2
    img.alpha_composite(glyph, (offset, offset))
    return img


class Pills(ctk.CTkFrame):
    def __init__(self, master, app, items, value, command, height=30, font_size=12):
        pad = 4
        super().__init__(master, fg_color=app.t["field"], corner_radius=(height + pad * 2) // 2)
        self.app = app
        self.command = command
        self.height = height
        self.font_size = font_size
        self.value = value
        self.buttons = {}
        self.set_items(items, value)

    def set_items(self, items, value):
        for button in self.buttons.values():
            button.destroy()
        self.buttons = {}
        self.value = value
        for index, item in enumerate(items):
            button = ctk.CTkButton(
                self,
                text=item,
                width=max(56, len(item) * 8 + 26),
                height=self.height,
                corner_radius=self.height // 2,
                font=F(self.font_size, True),
                command=lambda v=item: self.select(v),
            )
            button.grid(row=0, column=index, padx=(4, 4 if index == len(items) - 1 else 0), pady=4)
            self.buttons[item] = button
        self.paint()

    def paint(self):
        t = self.app.t
        for item, button in self.buttons.items():
            if item == self.value:
                button.configure(fg_color=t["accent"], hover_color=t["accent"], text_color=t["accent_text"])
            else:
                button.configure(fg_color="transparent", hover_color=t["row"], text_color=t["muted"])

    def select(self, value):
        self.value = value
        self.paint()
        self.command(value)


class Dialog(ctk.CTkToplevel):
    def __init__(self, app, title, width, height):
        super().__init__(app)
        self.app = app
        self.t = app.t
        self.title(title)
        self.resizable(False, False)
        self.configure(fg_color=self.t["card"])
        x = app.winfo_x() + max(0, (app.winfo_width() - width) // 2)
        y = app.winfo_y() + max(0, (app.winfo_height() - height) // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
        self.dialog_width = width
        self.transient(app)
        self.after(150, self._focus)

    def _focus(self):
        try:
            self.lift()
            self.focus_force()
            self.grab_set()
        except Exception:
            pass

    def heading(self, title, subtitle):
        ctk.CTkLabel(self, text=title, font=F(17, True), text_color=self.t["text"], anchor="w").pack(
            fill="x", padx=22, pady=(20, 0)
        )
        ctk.CTkLabel(
            self, text=subtitle, font=F(12), text_color=self.t["muted"], anchor="w", justify="left", wraplength=width_hint(self)
        ).pack(fill="x", padx=22, pady=(3, 10))


class ConfirmDialog(Dialog):
    def __init__(self, app, title, message, on_yes, yes_text="Confirm"):
        super().__init__(app, title, 380, 190)
        self.on_yes = on_yes
        self.heading(title, message)
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(side="bottom", fill="x", padx=22, pady=18)
        app.button(row, "Cancel", command=self.destroy, width=90).pack(side="right", padx=(8, 0))
        app.button(row, yes_text, primary=True, command=self.accept, width=110).pack(side="right")

    def accept(self):
        self.destroy()
        self.on_yes()
