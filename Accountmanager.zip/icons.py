import math
from functools import lru_cache

from PIL import Image, ImageDraw

SCALE = 8


def _rgba(color):
    color = color.lstrip("#")
    return tuple(int(color[i:i + 2], 16) for i in (0, 2, 4)) + (255,)


class Pen:
    def __init__(self, px, color, width=2.0):
        self.px = px
        self.k = px * SCALE / 24
        self.img = Image.new("RGBA", (px * SCALE, px * SCALE), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.img)
        self.color = _rgba(color)
        self.w = max(1, round(width * self.k))

    def pts(self, points):
        return [(x * self.k, y * self.k) for x, y in points]

    def line(self, points, width=None):
        w = round(width * self.k) if width else self.w
        pts = self.pts(points)
        self.d.line(pts, fill=self.color, width=w, joint="curve")
        r = w / 2
        for x, y in (pts[0], pts[-1]):
            self.d.ellipse((x - r, y - r, x + r, y + r), fill=self.color)

    def circle(self, cx, cy, r, fill=False):
        a, b = self.pts([(cx - r, cy - r), (cx + r, cy + r)])
        box = [a[0], a[1], b[0], b[1]]
        if fill:
            self.d.ellipse(box, fill=self.color)
        else:
            self.d.ellipse(box, outline=self.color, width=self.w)

    def arc(self, box, start, end):
        a, b = self.pts([(box[0], box[1]), (box[2], box[3])])
        self.d.arc([a[0], a[1], b[0], b[1]], start, end, fill=self.color, width=self.w)

    def rect(self, x0, y0, x1, y1, radius=0, fill=False):
        a, b = self.pts([(x0, y0), (x1, y1)])
        box = [a[0], a[1], b[0], b[1]]
        r = radius * self.k
        if fill:
            self.d.rounded_rectangle(box, radius=r, fill=self.color)
        else:
            self.d.rounded_rectangle(box, radius=r, outline=self.color, width=self.w)

    def poly(self, points):
        self.d.polygon(self.pts(points), fill=self.color)

    def finish(self):
        return self.img.resize((self.px, self.px), Image.LANCZOS)


def _home(p):
    p.line([(3, 11), (12, 3), (21, 11)])
    p.line([(5, 10), (5, 20), (19, 20), (19, 10)])
    p.line([(10, 20), (10, 14), (14, 14), (14, 20)])


def _users(p):
    p.circle(9, 8, 3.5)
    p.arc((2.5, 14, 15.5, 27), 190, 350)
    p.circle(17, 9, 2.7)
    p.arc((14, 15, 23, 24), 200, 340)


def _user(p):
    p.circle(12, 8, 4)
    p.arc((4, 14, 20, 30), 200, 340)


def _user_plus(p):
    p.circle(9, 8, 4)
    p.arc((1, 14, 17, 30), 200, 340)
    p.line([(19, 7), (19, 13)])
    p.line([(16, 10), (22, 10)])


def _settings(p):
    p.circle(12, 12, 3)
    p.circle(12, 12, 7)
    for i in range(8):
        a = math.radians(i * 45)
        p.line(
            [(12 + 7 * math.cos(a), 12 + 7 * math.sin(a)), (12 + 10 * math.cos(a), 12 + 10 * math.sin(a))],
            width=2.6,
        )


def _refresh(p):
    p.arc((4, 4, 20, 20), 30, 320)
    a = math.radians(320)
    cx, cy = 12 + 8 * math.cos(a), 12 + 8 * math.sin(a)
    tx, ty = -math.sin(a), math.cos(a)
    nx, ny = math.cos(a), math.sin(a)
    tip = (cx + tx * 3.2, cy + ty * 3.2)
    base = (cx - tx * 0.6, cy - ty * 0.6)
    p.poly([tip, (base[0] + nx * 3.4, base[1] + ny * 3.4), (base[0] - nx * 3.4, base[1] - ny * 3.4)])


def _plus(p):
    p.line([(12, 5), (12, 19)])
    p.line([(5, 12), (19, 12)])


def _search(p):
    p.circle(10.5, 10.5, 6.5)
    p.line([(15.5, 15.5), (20.5, 20.5)])


def _play(p):
    p.poly([(7, 4.5), (19.5, 12), (7, 19.5)])


def _trash(p):
    p.line([(4, 7), (20, 7)])
    p.line([(9, 7), (9, 4), (15, 4), (15, 7)])
    p.line([(6, 7), (7, 20), (17, 20), (18, 7)])
    p.line([(10, 11), (10, 16)])
    p.line([(14, 11), (14, 16)])


def _folder(p):
    p.line([(3, 7), (3, 19), (21, 19), (21, 9), (11, 9), (9, 6), (3, 6), (3, 7)])


def _check(p):
    p.line([(5, 12.5), (10, 17.5), (19, 7)])


def _close(p):
    p.line([(6, 6), (18, 18)])
    p.line([(18, 6), (6, 18)])


def _check_all(p):
    p.line([(2.5, 12.5), (7, 17), (15, 8)])
    p.line([(11, 15.5), (12.5, 17), (21, 7)])


def _key(p):
    p.circle(8, 15, 4.5)
    p.line([(11.5, 11.5), (20, 3.5)])
    p.line([(16.5, 7), (19, 9.5)])


def _lock(p):
    p.rect(5, 11, 19, 21, 2.5)
    p.arc((7.5, 3, 16.5, 17), 180, 360)
    p.line([(12, 15), (12, 17.5)])


def _palette(p):
    p.circle(12, 12, 9)
    p.circle(8, 10, 1.4, fill=True)
    p.circle(12, 7.5, 1.4, fill=True)
    p.circle(16, 10, 1.4, fill=True)
    p.circle(15.5, 15.5, 1.4, fill=True)


def _shield(p):
    p.line([(12, 3), (20, 6), (20, 12), (12, 21), (4, 12), (4, 6), (12, 3)])
    p.line([(8.5, 11.5), (11, 14), (15.5, 9)])


def _grid(p):
    p.rect(4, 4, 10.5, 10.5, 2)
    p.rect(13.5, 4, 20, 10.5, 2)
    p.rect(4, 13.5, 10.5, 20, 2)
    p.rect(13.5, 13.5, 20, 20, 2)


def _coin(p):
    p.circle(12, 12, 9)
    p.circle(12, 12, 4.5)


def _info(p):
    p.circle(12, 12, 9)
    p.line([(12, 11), (12, 17)])
    p.circle(12, 7.6, 1.2, fill=True)


def _sliders(p):
    p.line([(4, 7), (20, 7)])
    p.line([(4, 17), (20, 17)])
    p.circle(9, 7, 2.4, fill=True)
    p.circle(15, 17, 2.4, fill=True)


def _download(p):
    p.line([(12, 4), (12, 15)])
    p.line([(7, 11), (12, 16), (17, 11)])
    p.line([(5, 20), (19, 20)])


def _globe(p):
    p.circle(12, 12, 8.5)
    p.line([(3.5, 12), (20.5, 12)])
    p.arc((8, 3.5, 16, 20.5), 0, 360)


def _list(p):
    p.line([(8, 7), (20, 7)])
    p.line([(8, 12), (20, 12)])
    p.line([(8, 17), (20, 17)])
    p.circle(4.5, 7, 1, fill=True)
    p.circle(4.5, 12, 1, fill=True)
    p.circle(4.5, 17, 1, fill=True)


def _browser(p):
    p.rect(3, 5, 21, 19, radius=2.5)
    p.line([(3, 9.5), (21, 9.5)])


ICONS = {
    "download": _download,
    "globe": _globe,
    "list": _list,
    "browser": _browser,
    "home": _home,
    "users": _users,
    "user": _user,
    "user_plus": _user_plus,
    "settings": _settings,
    "refresh": _refresh,
    "plus": _plus,
    "search": _search,
    "play": _play,
    "trash": _trash,
    "folder": _folder,
    "check": _check,
    "close": _close,
    "check_all": _check_all,
    "key": _key,
    "lock": _lock,
    "palette": _palette,
    "shield": _shield,
    "grid": _grid,
    "coin": _coin,
    "info": _info,
    "sliders": _sliders,
}


@lru_cache(maxsize=512)
def render(name, px, color, width=2.0):
    pen = Pen(px, color, width)
    ICONS[name](pen)
    return pen.finish()
