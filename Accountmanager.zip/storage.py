import json
import os
import time

from cryptography.fernet import Fernet, InvalidToken

from .paths import data_dir

DEFAULT_SETTINGS = {
    "theme": "Rift",
    "place_id": "",
    "launch_delay": 6,
    "auto_refresh": True,
    "confirm_delete": True,
    "multi_instance": True,
    "roblox_version": "version-f0ea5da9412f4e35",
    "recent": [],
}


class Store:
    def __init__(self):
        self.dir = data_dir()
        self.accounts_file = self.dir / "accounts.dat"
        self.settings_file = self.dir / "settings.json"
        self.key_file = self.dir / "store.key"
        self.fernet = Fernet(self._key())
        self.accounts = []
        self.groups = ["Default"]
        self.settings = dict(DEFAULT_SETTINGS)
        self.load()

    def _key(self):
        if self.key_file.exists():
            return self.key_file.read_bytes().strip()
        key = Fernet.generate_key()
        self.key_file.write_bytes(key)
        try:
            os.chmod(self.key_file, 0o600)
        except OSError:
            pass
        return key

    def load(self):
        if self.settings_file.exists():
            try:
                data = json.loads(self.settings_file.read_text(encoding="utf-8"))
                self.settings.update({k: v for k, v in data.items() if k in DEFAULT_SETTINGS})
            except (OSError, ValueError):
                pass
        if self.accounts_file.exists():
            try:
                raw = self.fernet.decrypt(self.accounts_file.read_bytes())
                data = json.loads(raw.decode("utf-8"))
                self.accounts = data.get("accounts", [])
                self.groups = data.get("groups") or ["Default"]
            except (InvalidToken, ValueError, OSError):
                try:
                    self.accounts_file.replace(self.accounts_file.with_suffix(".bak"))
                except OSError:
                    pass
        if "Default" not in self.groups:
            self.groups.insert(0, "Default")
        for account in self.accounts:
            account.setdefault("group", "Default")
            account.setdefault("status", "unknown")
            account.setdefault("robux", None)
            account.setdefault("presence", 0)
            account.setdefault("display", account.get("name", ""))
            if account["group"] not in self.groups:
                account["group"] = "Default"

    def save(self):
        payload = json.dumps({"accounts": self.accounts, "groups": self.groups}).encode("utf-8")
        temp = self.accounts_file.with_suffix(".tmp")
        temp.write_bytes(self.fernet.encrypt(payload))
        os.replace(temp, self.accounts_file)

    def save_settings(self):
        temp = self.settings_file.with_suffix(".tmp")
        temp.write_text(json.dumps(self.settings, indent=2), encoding="utf-8")
        os.replace(temp, self.settings_file)

    def get(self, account_id):
        for account in self.accounts:
            if account["id"] == account_id:
                return account
        return None

    def add_account(self, info, cookie, group, status, robux):
        existing = self.get(info["id"])
        if existing:
            existing.update(cookie=cookie, name=info["name"], display=info["display"], status=status, robux=robux)
            self.save()
            return existing, False
        account = {
            "id": info["id"],
            "name": info["name"],
            "display": info["display"],
            "cookie": cookie,
            "group": group if group in self.groups else "Default",
            "status": status,
            "robux": robux,
            "presence": 0,
            "added": int(time.time()),
        }
        self.accounts.append(account)
        self.save()
        return account, True

    def update(self, account_id, **fields):
        account = self.get(account_id)
        if account:
            account.update(fields)

    def remove(self, ids):
        ids = set(ids)
        self.accounts = [a for a in self.accounts if a["id"] not in ids]
        self.save()

    def clear(self):
        self.accounts = []
        self.save()

    def set_group(self, ids, group):
        for account in self.accounts:
            if account["id"] in ids:
                account["group"] = group
        self.save()

    def add_group(self, name):
        name = name.strip()
        if not name or name in self.groups or name == "All":
            return False
        self.groups.append(name)
        self.save()
        return True

    def delete_group(self, name):
        if name == "Default" or name not in self.groups:
            return
        self.groups.remove(name)
        for account in self.accounts:
            if account["group"] == name:
                account["group"] = "Default"
        self.save()
