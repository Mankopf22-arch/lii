def _theme(**values):
    base = {"good": "#4ade80", "bad": "#f87171", "warn": "#fbbf24"}
    base.update(values)
    return base


THEMES = {
    "Rift": _theme(
        mode="dark", bg="#24242c", sidebar="#101015", card="#15151b", field="#0d0d12", row="#101016",
        border="#26262f", text="#f5f5f7", muted="#8c8c98", accent="#f5f5f7", accent_hover="#d9d9de",
        accent_text="#0d0d12",
    ),
    "Midnight": _theme(
        mode="dark", bg="#0b1120", sidebar="#070b16", card="#0f172a", field="#0a1020", row="#0c1426",
        border="#1b2640", text="#e6edf8", muted="#7d8aa5", accent="#7aa2ff", accent_hover="#5f8bf5",
        accent_text="#06101f",
    ),
    "Violet": _theme(
        mode="dark", bg="#1a1426", sidebar="#110c1b", card="#171122", field="#0f0a19", row="#130e1e",
        border="#2a2040", text="#f1ecfb", muted="#9488b0", accent="#a78bfa", accent_hover="#8f6ff0",
        accent_text="#120a24",
    ),
    "Emerald": _theme(
        mode="dark", bg="#0f1a17", sidebar="#0a1210", card="#0e1714", field="#09110f", row="#0b1411",
        border="#1c2e29", text="#e8f6f1", muted="#7d9a91", accent="#34d399", accent_hover="#22b883",
        accent_text="#04130d",
    ),
    "Rose": _theme(
        mode="dark", bg="#201318", sidebar="#150a0e", card="#1a0f13", field="#12080b", row="#150b0f",
        border="#33202a", text="#fbeff2", muted="#a8858f", accent="#fb7185", accent_hover="#ec5a70",
        accent_text="#1f060b",
    ),
    "Sunset": _theme(
        mode="dark", bg="#1e1710", sidebar="#140e08", card="#18120c", field="#100b06", row="#130d08",
        border="#33271a", text="#faf1e6", muted="#a89580", accent="#fb923c", accent_hover="#ea7a1e",
        accent_text="#1c0d02",
    ),
    "Light": _theme(
        mode="light", bg="#e6e8ef", sidebar="#ffffff", card="#ffffff", field="#eef0f5", row="#f4f5f9",
        border="#dcdfe8", text="#111827", muted="#6b7280", accent="#111827", accent_hover="#2b3445",
        accent_text="#ffffff", good="#16a34a", bad="#dc2626", warn="#d97706",
    ),
}
