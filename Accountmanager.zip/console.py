import os
import sys
import time

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
PURPLE = "\033[38;5;141m"
GREEN = "\033[38;5;84m"
RED = "\033[38;5;203m"
YELLOW = "\033[38;5;221m"
WHITE = "\033[38;5;255m"


def enable():
    if os.name == "nt":
        os.system("")
        try:
            os.system("title Vibes Manager")
        except Exception:
            pass


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def banner(subtitle):
    clear()
    lines = [
        r" __   _____ ____  _____ ____  ",
        r" \ \ / /_ _| __ )| ____/ ___| ",
        r"  \ V / | ||  _ \|  _| \___ \ ",
        r"   \_/ |___|____/|_____|____/ ",
    ]
    print()
    for line in lines:
        print(PURPLE + BOLD + line + RESET)
    print()
    print(WHITE + BOLD + "  " + subtitle + RESET)
    print(DIM + "  " + "-" * 44 + RESET)
    print()


def info(message):
    print(f"  {PURPLE}>{RESET} {message}")


def ok(message):
    print(f"  {GREEN}+{RESET} {message}")


def warn(message):
    print(f"  {YELLOW}!{RESET} {message}")


def fail(message):
    print(f"  {RED}x{RESET} {message}")


def progress(value, text):
    width = 28
    filled = int(width * max(0.0, min(1.0, value)))
    bar = "#" * filled + "-" * (width - filled)
    line = f"  {PURPLE}>{RESET} [{bar}] {int(value * 100):3d}%  {text}"
    sys.stdout.write("\r" + line[:110].ljust(110))
    sys.stdout.flush()


def progress_end():
    sys.stdout.write("\n")
    sys.stdout.flush()


def ask(prompt):
    try:
        return input(f"  {PURPLE}>{RESET} {prompt}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit(1)


def pause(seconds):
    time.sleep(seconds)
