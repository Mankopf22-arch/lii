import os
import random
import re
import subprocess
import sys
import time
import uuid
import webbrowser
from pathlib import Path
from urllib.parse import quote

import requests

from . import installer

LOGIN_URL = "https://www.roblox.com/login"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)
TIMEOUT = 12


class RobloxError(Exception):
    pass


def _request(method, url, **kwargs):
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    headers.update(kwargs.pop("headers", {}))
    try:
        return requests.request(method, url, headers=headers, timeout=TIMEOUT, **kwargs)
    except requests.RequestException as error:
        raise RobloxError("Network error") from error


def _cookie(cookie):
    return {"Cookie": f".ROBLOSECURITY={cookie}"}


def clean_cookie(raw):
    raw = raw.strip().strip('"').strip("'")
    match = re.search(r"\.ROBLOSECURITY=([^;\s]+)", raw)
    if match:
        raw = match.group(1)
    return raw


def looks_like_cookie(text):
    text = clean_cookie(text or "")
    return text.startswith("_|WARNING") and len(text) > 200 and "\n" not in text


def open_login():
    webbrowser.open(LOGIN_URL)


def authenticate(cookie):
    response = _request("GET", "https://users.roblox.com/v1/users/authenticated", headers=_cookie(cookie))
    if response.status_code == 200:
        data = response.json()
        return {"id": data["id"], "name": data["name"], "display": data.get("displayName", data["name"])}
    if response.status_code in (401, 403):
        return None
    raise RobloxError(f"Unexpected response ({response.status_code})")


def is_banned(user_id):
    try:
        response = _request("GET", f"https://users.roblox.com/v1/users/{user_id}")
        return bool(response.json().get("isBanned"))
    except Exception:
        return False


def robux(cookie):
    try:
        response = _request("GET", "https://economy.roblox.com/v1/user/currency", headers=_cookie(cookie))
        if response.status_code == 200:
            return int(response.json().get("robux", 0))
    except Exception:
        pass
    return None


def csrf(cookie):
    response = _request("POST", "https://auth.roblox.com/v2/logout", headers=_cookie(cookie))
    token = response.headers.get("x-csrf-token")
    if not token:
        raise RobloxError("Could not get a CSRF token")
    return token


def presence(user_id, cookie):
    try:
        headers = _cookie(cookie)
        headers["x-csrf-token"] = csrf(cookie)
        response = _request(
            "POST", "https://presence.roblox.com/v1/presence/users", headers=headers, json={"userIds": [user_id]}
        )
        return int(response.json()["userPresences"][0]["userPresenceType"])
    except Exception:
        return 0


def _download(url):
    try:
        response = _request("GET", url)
        if response.status_code == 200:
            return response.content
    except Exception:
        pass
    return None


def headshot(user_id):
    try:
        response = _request(
            "GET",
            "https://thumbnails.roblox.com/v1/users/avatar-headshot",
            params={"userIds": user_id, "size": "150x150", "format": "Png", "isCircular": "false"},
        )
        url = response.json()["data"][0].get("imageUrl")
        return _download(url) if url else None
    except Exception:
        return None


def place_info(place_id):
    try:
        response = _request("GET", f"https://apis.roblox.com/universes/v1/places/{place_id}/universe")
        universe = response.json().get("universeId")
        if not universe:
            return None
        game = _request("GET", "https://games.roblox.com/v1/games", params={"universeIds": universe}).json()["data"][0]
        votes = _request("GET", "https://games.roblox.com/v1/games/votes", params={"universeIds": universe}).json()
        likes = votes["data"][0].get("upVotes", 0) if votes.get("data") else 0
        icon = None
        thumbs = _request(
            "GET",
            "https://thumbnails.roblox.com/v1/games/icons",
            params={"universeIds": universe, "size": "150x150", "format": "Png", "isCircular": "false"},
        ).json()
        if thumbs.get("data") and thumbs["data"][0].get("imageUrl"):
            icon = _download(thumbs["data"][0]["imageUrl"])
        return {
            "universe": universe,
            "creator": (game.get("creator") or {}).get("name", ""),
            "name": game.get("name", "Unknown"),
            "playing": game.get("playing", 0),
            "favorites": game.get("favoritedCount", 0),
            "likes": likes,
            "icon": icon,
        }
    except Exception:
        return None


def installed():
    if os.name == "nt":
        return installer.is_installed()
    if sys.platform == "darwin":
        return Path("/Applications/Roblox.app").exists()
    return False


def open_uri(uri):
    if os.name == "nt":
        os.startfile(uri)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", uri])
    else:
        webbrowser.open(uri)


def build_uri(ticket, place_id, job_id=""):
    tracker = random.randint(10_000_000_000, 99_999_999_999)
    launcher = launcher_url(place_id, job_id, tracker)
    return (
        "roblox-player:1+launchmode:play+gameinfo:"
        + ticket
        + f"+launchtime:{int(time.time() * 1000)}"
        + "+placelauncherurl:"
        + quote(launcher, safe="")
        + f"+browsertrackerid:{tracker}+robloxLocale:en_us+gameLocale:en_us+channel:+LaunchExp:InApp"
    )


_handles = []


def enable_multi():
    if os.name != "nt" or _handles:
        return
    import ctypes

    kernel = ctypes.windll.kernel32
    kernel.CreateMutexW.restype = ctypes.c_void_p
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    for name in ("ROBLOX_singletonMutex", "ROBLOX_singletonEvent"):
        handle = kernel.CreateMutexW(None, 1, name)
        if handle:
            _handles.append(handle)


def launcher_url(place_id, job_id, tracker):
    if job_id:
        request = f"RequestGameJob&placeId={place_id}&gameId={job_id}"
    else:
        request = f"RequestGame&placeId={place_id}"
    return (
        "https://assetgame.roblox.com/game/PlaceLauncher.ashx?request="
        + request
        + f"&browserTrackerId={tracker}&isPlayTogetherGame=false"
    )


def start_player(exe, ticket, place_id, job_id):
    tracker = random.randint(10_000_000_000, 99_999_999_999)
    arguments = [
        str(exe),
        "--app",
        "-t",
        ticket,
        "-j",
        launcher_url(place_id, job_id, tracker),
        "-b",
        str(tracker),
        f"--launchtime={int(time.time() * 1000)}",
        "--rloc",
        "en_us",
        "--gloc",
        "en_us",
    ]
    subprocess.Popen(arguments, cwd=str(Path(exe).parent), close_fds=True)


def launch(cookie, place_id, job_id="", multi=False):
    if not installed():
        raise RobloxError("Roblox is not installed")
    if multi:
        enable_multi()
    token = csrf(cookie)
    headers = _cookie(cookie)
    headers.update(
        {
            "x-csrf-token": token,
            "Referer": f"https://www.roblox.com/games/{place_id}",
            "Origin": "https://www.roblox.com",
        }
    )
    response = _request("POST", "https://auth.roblox.com/v1/authentication-ticket", headers=headers, json={})
    ticket = response.headers.get("rbx-authentication-ticket")
    if not ticket:
        raise RobloxError("Login rejected, the cookie may be expired")
    exe = installer.player_exe()
    if os.name == "nt" and exe:
        start_player(exe, ticket, place_id, job_id)
    else:
        open_uri(build_uri(ticket, place_id, job_id))


def _like_percent(up, down):
    total = (up or 0) + (down or 0)
    return round(100 * (up or 0) / total) if total else None


def _fill_places(games):
    missing = [g["universe"] for g in games if not g["place"] and g["universe"]]
    if not missing:
        return
    try:
        data = _request(
            "GET", "https://games.roblox.com/v1/games", params={"universeIds": ",".join(str(i) for i in missing)}
        ).json()["data"]
    except Exception:
        return
    lookup = {item["id"]: item.get("rootPlaceId") for item in data}
    for game in games:
        if not game["place"]:
            game["place"] = lookup.get(game["universe"])


def _search_omni(query):
    response = _request(
        "GET",
        "https://apis.roblox.com/search-api/omni-search",
        params={"searchQuery": query, "pageToken": "", "sessionId": str(uuid.uuid4()), "pageType": "all"},
    )
    if response.status_code != 200:
        raise RobloxError(f"Search failed ({response.status_code})")
    games = []
    for group in response.json().get("searchResults", []):
        if group.get("contentGroupType") != "Game":
            continue
        for item in group.get("contents", []):
            games.append(
                {
                    "universe": item.get("universeId"),
                    "place": item.get("rootPlaceId"),
                    "name": item.get("name", "Unknown"),
                    "creator": item.get("creatorName", ""),
                    "playing": item.get("playerCount", 0),
                    "likes": _like_percent(item.get("totalUpVotes"), item.get("totalDownVotes")),
                }
            )
    return games


def _search_legacy(query):
    response = _request(
        "GET",
        "https://games.roblox.com/v1/games/list",
        params={"model.keyword": query, "model.maxRows": 30, "model.startRows": 0},
    )
    if response.status_code != 200:
        raise RobloxError(f"Search failed ({response.status_code})")
    return [
        {
            "universe": item.get("universeId"),
            "place": item.get("placeId"),
            "name": item.get("name", "Unknown"),
            "creator": item.get("creatorName", ""),
            "playing": item.get("playerCount", 0),
            "likes": _like_percent(item.get("totalUpVotes"), item.get("totalDownVotes")),
        }
        for item in response.json().get("games", [])
    ]


def search_games(query, limit=30):
    query = query.strip()
    if not query:
        return []
    try:
        games = _search_omni(query)
    except RobloxError:
        games = _search_legacy(query)
    except (ValueError, KeyError, TypeError) as error:
        raise RobloxError("Unexpected search response") from error
    games = [g for g in games if g["universe"]][:limit]
    _fill_places(games)
    return [g for g in games if g["place"]]


def game_icons(universe_ids):
    ids = [str(i) for i in universe_ids if i]
    if not ids:
        return {}
    try:
        data = _request(
            "GET",
            "https://thumbnails.roblox.com/v1/games/icons",
            params={"universeIds": ",".join(ids), "size": "150x150", "format": "Png", "isCircular": "false"},
        ).json()["data"]
    except Exception:
        return {}
    return {item["targetId"]: item["imageUrl"] for item in data if item.get("imageUrl")}


def download_image(url):
    return _download(url)
