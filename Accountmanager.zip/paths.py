import os
import sys
from pathlib import Path

DATA_FOLDER = "VibesManager"
ROOT = Path(__file__).resolve().parent.parent


def data_dir():
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    path = base / DATA_FOLDER
    path.mkdir(parents=True, exist_ok=True)
    return path
