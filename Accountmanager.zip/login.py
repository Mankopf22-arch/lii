import importlib.util
import os
import subprocess
import sys
import threading
from pathlib import Path

from .paths import ROOT

SCRIPT = ROOT / "vibes_login.py"


def available():
    return SCRIPT.exists() and importlib.util.find_spec("webview") is not None


def interpreter():
    exe = Path(sys.executable)
    if os.name == "nt":
        console = exe.with_name("python.exe")
        if console.exists():
            return str(console)
    return str(exe)


def start(on_cookie, on_close):
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    process = subprocess.Popen(
        [interpreter(), str(SCRIPT)],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        text=True,
        cwd=str(ROOT),
        creationflags=flags,
    )

    def read():
        found = False
        for line in process.stdout:
            if line.startswith("COOKIE:"):
                found = True
                on_cookie(line[len("COOKIE:"):].strip())
        process.wait()
        on_close(found)

    threading.Thread(target=read, daemon=True).start()
    return process
