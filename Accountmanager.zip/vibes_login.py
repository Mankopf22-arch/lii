import os
import sys
import threading
import time

URL = "https://www.roblox.com/login"
COOKIE = ".ROBLOSECURITY"


def find_cookie(window):
    try:
        jars = window.get_cookies()
    except Exception:
        return None
    for jar in jars or []:
        try:
            morsel = jar.get(COOKIE)
        except Exception:
            morsel = None
        if morsel is None:
            continue
        value = str(getattr(morsel, "value", morsel))
        if value.startswith("_|WARNING"):
            return value
    return None


def watch(window):
    time.sleep(2)
    while True:
        value = find_cookie(window)
        if value:
            sys.stdout.write("COOKIE:" + value + "\n")
            sys.stdout.flush()
            try:
                window.destroy()
            except Exception:
                pass
            return
        time.sleep(1)


def main():
    import webview

    window = webview.create_window("Roblox login", URL, width=480, height=720)
    webview.start(watch, window, private_mode=True)
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
