import threading

import customtkinter as ctk

from . import login, roblox
from .ui import Dialog, F, Pills

MODES = ["Cookie login", "Manual login"]

WINDOW_STEPS = (
    "Press the button to open a Roblox login window. Sign in there, and the account is added to the manager "
    "automatically as soon as you are logged in."
)
MANUAL_STEPS = (
    "1. Press the button to open roblox.com/login in your browser and sign in.\n"
    "2. Press F12, open Application (Storage in Firefox), then Cookies, then roblox.com.\n"
    "3. Copy the value of .ROBLOSECURITY. It is picked up from the clipboard automatically."
)
COOKIE_STEPS = "Paste one .ROBLOSECURITY cookie per line. Cookies are encrypted on this computer and only sent to roblox.com."


def option_menu(parent, t, values, variable, width):
    return ctk.CTkOptionMenu(
        parent,
        values=values,
        variable=variable,
        fg_color=t["field"],
        button_color=t["field"],
        button_hover_color=t["row"],
        dropdown_fg_color=t["card"],
        dropdown_hover_color=t["row"],
        dropdown_text_color=t["text"],
        text_color=t["text"],
        corner_radius=12,
        height=30,
        width=width,
        font=F(12),
    )


class AddAccountDialog(Dialog):
    def __init__(self, app):
        super().__init__(app, "Add account", 470, 560)
        t = self.t
        self.mode = MODES[0]
        self.busy = False
        self.last_clip = ""
        self.poll_job = None
        self.login_process = None
        self.heading("Add Roblox account", "Sign in with a cookie or through your browser.")
        self.pills = Pills(self, app, MODES, self.mode, self.set_mode, height=28)
        self.pills.pack(padx=22, anchor="w")
        self.steps = ctk.CTkLabel(
            self, text=COOKIE_STEPS, font=F(12), text_color=t["muted"], anchor="w", justify="left", wraplength=420
        )
        self.steps.pack(fill="x", padx=22, pady=(12, 8))
        self.browser_row = ctk.CTkFrame(self, fg_color="transparent")
        app.button(
            self.browser_row, "Open login window", icon="browser", command=self.open_login, width=170
        ).pack(side="left")
        self.watch = ctk.CTkLabel(self.browser_row, text="", font=F(11), text_color=t["muted"])
        self.watch.pack(side="left", padx=12)
        self.box = ctk.CTkTextbox(
            self,
            height=110,
            fg_color=t["field"],
            text_color=t["text"],
            border_width=1,
            border_color=t["border"],
            corner_radius=12,
            font=F(11),
        )
        self.box.pack(fill="x", padx=22, pady=(4, 0))
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=22, pady=(12, 0))
        ctk.CTkLabel(row, text="GROUP", font=F(10, True), text_color=t["muted"]).pack(side="left")
        self.group = ctk.StringVar(value=app.store.groups[0])
        option_menu(row, t, app.store.groups, self.group, 160).pack(side="left", padx=10)
        app.button(row, "Paste", icon="check", command=self.paste, width=90).pack(side="right")
        self.message = ctk.CTkLabel(self, text="", font=F(12), text_color=t["bad"], anchor="w", wraplength=420)
        self.message.pack(fill="x", padx=22, pady=(10, 0))
        buttons = ctk.CTkFrame(self, fg_color="transparent")
        buttons.pack(side="bottom", fill="x", padx=22, pady=18)
        app.button(buttons, "Cancel", command=self.destroy, width=90).pack(side="right", padx=(8, 0))
        self.submit = app.button(buttons, "Add accounts", icon="user_plus", primary=True, command=self.add, width=140)
        self.submit.pack(side="right")

    def set_mode(self, value):
        self.mode = value
        if value == MODES[1]:
            self.steps.configure(text=WINDOW_STEPS if login.available() else MANUAL_STEPS)
            self.browser_row.pack(fill="x", padx=22, pady=(0, 6), before=self.box)
            self.watch.configure(text="")
        else:
            self.steps.configure(text=COOKIE_STEPS)
            self.browser_row.pack_forget()
            self.stop_poll()

    def open_login(self):
        if login.available():
            if self.login_process is not None and self.login_process.poll() is None:
                self.watch.configure(text="Login window is already open")
                return
            self.watch.configure(text="Waiting for login...")
            self.login_process = login.start(
                lambda cookie: self.app.ui(self.got_cookie, cookie),
                lambda found: self.app.ui(self.login_closed, found),
            )
            return
        roblox.open_login()
        self.last_clip = self.read_clipboard()
        self.watch.configure(text="Waiting for the cookie...")
        self.schedule_poll()

    def got_cookie(self, cookie):
        if not self.winfo_exists():
            return
        self.box.delete("1.0", "end")
        self.box.insert("1.0", cookie)
        self.watch.configure(text="Logged in")
        self.add()

    def login_closed(self, found):
        if self.winfo_exists() and not found and not self.busy:
            self.watch.configure(text="Login window closed")

    def read_clipboard(self):
        try:
            return self.clipboard_get()
        except Exception:
            return ""

    def schedule_poll(self):
        self.stop_poll()
        self.poll_job = self.after(700, self.poll)

    def stop_poll(self):
        if self.poll_job is not None:
            try:
                self.after_cancel(self.poll_job)
            except Exception:
                pass
            self.poll_job = None

    def poll(self):
        self.poll_job = None
        if self.mode != MODES[1] or not self.winfo_exists():
            return
        if not self.busy:
            text = self.read_clipboard()
            if text != self.last_clip:
                self.last_clip = text
                if roblox.looks_like_cookie(text):
                    self.box.delete("1.0", "end")
                    self.box.insert("1.0", roblox.clean_cookie(text))
                    self.watch.configure(text="Cookie found")
                    self.add()
                    return
        self.schedule_poll()

    def paste(self):
        text = self.read_clipboard().strip()
        if not text:
            self.message.configure(text="Clipboard is empty", text_color=self.t["bad"])
            return
        current = self.box.get("1.0", "end").strip()
        if current:
            self.box.insert("end", "\n")
        self.box.insert("end", roblox.clean_cookie(text))
        self.message.configure(text="")

    def destroy(self):
        self.stop_poll()
        if self.login_process is not None and self.login_process.poll() is None:
            try:
                self.login_process.terminate()
            except Exception:
                pass
        super().destroy()

    def add(self):
        lines = [roblox.clean_cookie(line) for line in self.box.get("1.0", "end").splitlines()]
        cookies = [line for line in lines if line]
        if not cookies:
            self.message.configure(text="Paste at least one cookie", text_color=self.t["bad"])
            return
        self.busy = True
        self.submit.configure(state="disabled", text="Checking...")
        self.message.configure(text="")
        group = self.group.get()
        threading.Thread(target=self.work, args=(cookies, group), daemon=True).start()

    def work(self, cookies, group):
        results = []
        for cookie in cookies:
            try:
                info = roblox.authenticate(cookie)
            except roblox.RobloxError:
                results.append((cookie, None, "error", None))
                continue
            if info is None:
                results.append((cookie, None, "invalid", None))
                continue
            status = "banned" if roblox.is_banned(info["id"]) else "valid"
            results.append((cookie, info, status, roblox.robux(cookie)))
        self.app.ui(self.done, results, group)

    def done(self, results, group):
        added = []
        failed = 0
        for cookie, info, status, robux in results:
            if info is None:
                failed += 1
                continue
            self.app.store.add_account(info, cookie, group, status, robux)
            added.append(info["name"])
        self.busy = False
        for name in added:
            self.app.log(f"Added account {name}")
        if failed:
            self.app.log(f"{failed} cookie(s) rejected")
        self.app.render_accounts()
        self.app.ensure_avatars()
        if not self.winfo_exists():
            return
        if failed == 0:
            self.destroy()
            self.app.toast(f"Added {len(added)} account" + ("s" if len(added) != 1 else ""), "ok")
            return
        self.submit.configure(state="normal", text="Add accounts")
        self.message.configure(
            text=f"Added {len(added)}, {failed} cookie" + ("s were" if failed != 1 else " was") + " invalid or unreachable",
            text_color=self.t["bad"],
        )
        if self.mode == MODES[1]:
            self.watch.configure(text="Login failed, try again")


class GroupsDialog(Dialog):
    def __init__(self, app):
        super().__init__(app, "Manage groups", 400, 470)
        t = self.t
        self.heading("Manage groups", "Create groups and move selected accounts into them.")
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=22)
        self.entry = ctk.CTkEntry(
            row,
            placeholder_text="New group name",
            fg_color=t["field"],
            border_width=0,
            text_color=t["text"],
            placeholder_text_color=t["muted"],
            corner_radius=16,
            height=34,
            font=F(12),
        )
        self.entry.pack(side="left", fill="x", expand=True)
        app.button(row, "Create", icon="plus", primary=True, command=self.create, width=90).pack(side="left", padx=(8, 0))
        self.list = ctk.CTkScrollableFrame(
            self,
            fg_color=t["field"],
            corner_radius=14,
            height=170,
            scrollbar_button_color=t["border"],
            scrollbar_button_hover_color=t["muted"],
        )
        self.list.pack(fill="x", padx=22, pady=12)
        for name in app.store.groups:
            item = ctk.CTkFrame(self.list, fg_color="transparent")
            item.pack(fill="x", pady=1)
            count = sum(1 for a in app.store.accounts if a["group"] == name)
            ctk.CTkLabel(item, text=name, font=F(12, True), text_color=t["text"]).pack(side="left", padx=8)
            ctk.CTkLabel(item, text=str(count), font=F(11), text_color=t["muted"]).pack(side="left")
            if name != "Default":
                ctk.CTkButton(
                    item,
                    text="",
                    image=app.icon("trash", 14, t["bad"]),
                    width=28,
                    height=28,
                    corner_radius=14,
                    fg_color="transparent",
                    hover_color=t["row"],
                    command=lambda n=name: self.remove(n),
                ).pack(side="right")
        ctk.CTkLabel(self, text="MOVE SELECTED ACCOUNTS", font=F(10, True), text_color=t["muted"], anchor="w").pack(
            fill="x", padx=22
        )
        move = ctk.CTkFrame(self, fg_color="transparent")
        move.pack(fill="x", padx=22, pady=(6, 0))
        self.target = ctk.StringVar(value=app.store.groups[0])
        option_menu(move, t, app.store.groups, self.target, 180).pack(side="left")
        app.button(move, "Move", icon="folder", command=self.move, width=90).pack(side="left", padx=8)
        app.button(self, "Done", primary=True, command=self.destroy, width=90).pack(
            side="bottom", anchor="e", padx=22, pady=16
        )

    def create(self):
        if self.app.store.add_group(self.entry.get()):
            self.destroy()
            self.app.build()
            GroupsDialog(self.app)
        else:
            self.app.toast("Group name is empty or already exists", "error")

    def remove(self, name):
        self.app.store.delete_group(name)
        if self.app.group_filter == name:
            self.app.group_filter = "All"
        self.destroy()
        self.app.build()
        GroupsDialog(self.app)

    def move(self):
        ids = self.app.selected_ids()
        if not ids:
            self.app.toast("Select accounts first", "error")
            return
        self.app.store.set_group(ids, self.target.get())
        self.destroy()
        self.app.build()
        self.app.toast(f"Moved {len(ids)} account" + ("s" if len(ids) != 1 else ""), "ok")
