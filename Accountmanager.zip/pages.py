import os
import subprocess
import sys
import threading
import time
import webbrowser
from concurrent.futures import ThreadPoolExecutor

import customtkinter as ctk

from . import VERSION, installer, licensing, roblox
from .dialogs import option_menu
from .paths import data_dir
from .themes import THEMES
from .ui import ConfirmDialog, F, log_error, placeholder_square, rounded_image, short

LAUNCH_SELECTED = "Selected accounts"
MAX_RECENT = 12


class PagesMixin:
    def launch_choices(self):
        names = [a["name"] for a in self.store.accounts]
        values = [LAUNCH_SELECTED] + names
        if self.launch_as.get() not in values:
            self.launch_as.set(LAUNCH_SELECTED)
        return values

    def launch_ids(self):
        choice = self.launch_as.get()
        if choice == LAUNCH_SELECTED:
            return self.selected_ids()
        for account in self.store.accounts:
            if account["name"] == choice:
                return [account["id"]]
        return []

    def recent_games(self):
        games = []
        for item in self.store.settings.get("recent", []):
            games.append(
                {
                    "universe": item.get("universe"),
                    "place": item.get("place"),
                    "name": item.get("name", "Unknown"),
                    "creator": item.get("creator", ""),
                    "playing": None,
                    "likes": None,
                }
            )
        return games

    def remember_game(self, game):
        entry = {key: game.get(key) for key in ("universe", "place", "name", "creator")}
        recent = [e for e in self.store.settings.get("recent", []) if e.get("place") != entry["place"]]
        recent.insert(0, entry)
        self.store.settings["recent"] = recent[:MAX_RECENT]
        self.store.save_settings()

    def games_page(self):
        t = self.t
        c = self.content
        c.grid_rowconfigure(2, weight=1)
        self.page_header(c, "grid", "Games", "Search by name or Place ID and launch straight into a game")

        bar = self.card(c)
        bar.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        inner = ctk.CTkFrame(bar, fg_color="transparent")
        inner.pack(fill="x", padx=14, pady=12)
        box = ctk.CTkFrame(inner, fg_color=t["field"], corner_radius=18, height=36)
        box.pack(side="left", fill="x", expand=True)
        box.pack_propagate(False)
        ctk.CTkLabel(box, text="", image=self.icon("search", 15, t["muted"])).pack(side="left", padx=(12, 2))
        self.game_entry = ctk.CTkEntry(
            box,
            placeholder_text="Search games or paste a Place ID...",
            fg_color="transparent",
            border_width=0,
            text_color=t["text"],
            placeholder_text_color=t["muted"],
            height=34,
            font=F(12),
        )
        self.game_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        if self.game_query:
            self.game_entry.insert(0, self.game_query)
        self.game_entry.bind("<Return>", lambda event: self.search_games())
        self.button(inner, "Search", icon="search", primary=True, command=self.search_games, width=100).pack(
            side="left", padx=(10, 14)
        )
        self.label(inner, "LAUNCH AS", 9, True, t["muted"]).pack(side="left", padx=(0, 8))
        option_menu(inner, t, self.launch_choices(), self.launch_as, 170).pack(side="left")

        card = self.card(c)
        card.grid(row=2, column=0, sticky="nsew")
        head = ctk.CTkFrame(card, fg_color="transparent")
        head.pack(fill="x", padx=18, pady=(12, 2))
        self.game_title_label = self.section_title(head, "")
        self.game_title_label.pack(side="left")
        self.game_list = ctk.CTkScrollableFrame(
            card,
            fg_color="transparent",
            corner_radius=0,
            scrollbar_button_color=t["border"],
            scrollbar_button_hover_color=t["muted"],
        )
        self.game_list.pack(fill="both", expand=True, padx=(10, 4), pady=(0, 10))
        self.render_games()
        if self.game_results is None:
            self.load_icons([g["universe"] for g in self.recent_games()])

    def render_games(self):
        if self.page != "games" or self.game_list is None:
            return
        t = self.t
        try:
            for widget in self.game_list.winfo_children():
                widget.destroy()
        except Exception:
            return
        if self.game_busy:
            self.game_title_label.configure(text="SEARCHING")
            self.label(self.game_list, "Searching...", 12, False, t["muted"]).pack(pady=30)
            return
        shown = self.recent_games() if self.game_results is None else self.game_results
        title = "RECENT" if self.game_results is None else f"RESULTS · {len(shown)}"
        self.game_title_label.configure(text=title)
        if not shown:
            message = "Search for a game above. Games you play show up here." if self.game_results is None else "No games found."
            self.label(self.game_list, message, 12, False, t["muted"]).pack(pady=30)
            return
        for game in shown:
            self.game_row(game)

    def game_image(self, universe):
        if universe in self.game_icon_images:
            return self.game_icon_images[universe]
        t = self.t
        data = self.game_icon_bytes.get(universe)
        try:
            if data:
                image = rounded_image(data, 40, 10)
            else:
                image = placeholder_square(40, t["field"], t["muted"], 10)
        except Exception:
            image = placeholder_square(40, t["field"], t["muted"], 10)
        photo = ctk.CTkImage(light_image=image, dark_image=image, size=(40, 40))
        if data:
            self.game_icon_images[universe] = photo
        return photo

    def game_row(self, game):
        t = self.t
        row = ctk.CTkFrame(self.game_list, fg_color=t["row"], corner_radius=16, height=56)
        row.pack(fill="x", pady=3, padx=(0, 6))
        row.pack_propagate(False)
        ctk.CTkLabel(row, text="", image=self.game_image(game.get("universe")), width=40, height=40).pack(
            side="left", padx=(12, 10)
        )
        self.button(row, "Play", icon="play", primary=True, command=lambda g=game: self.play_game(g), width=84, height=30).pack(
            side="right", padx=(4, 12)
        )
        self.button(row, "Use", command=lambda g=game: self.use_game(g), width=60, height=30).pack(side="right", padx=4)
        info = ctk.CTkFrame(row, fg_color="transparent")
        info.pack(side="left", fill="x", expand=True)
        self.label(info, game["name"], 13, True, anchor="w").pack(fill="x", pady=(9, 0))
        parts = []
        if game.get("creator"):
            parts.append(game["creator"])
        if game.get("playing") is not None:
            parts.append(f"{short(game['playing'])} playing")
        if game.get("likes") is not None:
            parts.append(f"{game['likes']}% liked")
        parts.append(f"Place {game['place']}")
        self.label(info, " · ".join(parts), 10, False, t["muted"], anchor="w").pack(fill="x")

    def search_games(self):
        if self.game_entry is None or self.game_busy:
            return
        query = self.game_entry.get().strip()
        self.game_query = query
        if not query:
            self.game_results = None
            self.render_games()
            return
        self.game_busy = True
        self.render_games()
        threading.Thread(target=self._search_worker, args=(query,), daemon=True).start()

    def _search_worker(self, query):
        icons = {}
        try:
            if query.isdigit():
                info = roblox.place_info(query)
                games = []
                if info:
                    games = [
                        {
                            "universe": info["universe"],
                            "place": int(query),
                            "name": info["name"],
                            "creator": info.get("creator", ""),
                            "playing": info.get("playing"),
                            "likes": None,
                        }
                    ]
                    if info.get("icon"):
                        icons[info["universe"]] = info["icon"]
            else:
                games = roblox.search_games(query)
        except roblox.RobloxError as error:
            self.ui(self._search_done, None, {}, query, str(error))
            return
        self.ui(self._search_done, games, icons, query, "")
        if games and not query.isdigit():
            self.load_icons([g["universe"] for g in games])

    def _search_done(self, games, icons, query, error):
        self.game_busy = False
        if games is None:
            self.log(f"Search failed: {error}")
            self.toast(error or "Search failed", "error")
        else:
            self.game_results = games
            self.game_icon_bytes.update(icons)
            self.log(f"Search '{query}': {len(games)} result(s)")
        self.render_games()

    def load_icons(self, universes):
        wanted = [u for u in universes if u and u not in self.game_icon_bytes and u not in self.icons_pending]
        if not wanted:
            return
        self.icons_pending.update(wanted)
        threading.Thread(target=self._icon_worker, args=(wanted,), daemon=True).start()

    def _icon_worker(self, universes):
        urls = roblox.game_icons(universes)
        icons = {}
        if urls:
            with ThreadPoolExecutor(max_workers=6) as pool:
                data = list(pool.map(roblox.download_image, urls.values()))
            icons = {uid: d for uid, d in zip(urls.keys(), data) if d}
        self.ui(self._icons_done, universes, icons)

    def _icons_done(self, universes, icons):
        self.icons_pending.difference_update(universes)
        self.game_icon_bytes.update(icons)
        if icons:
            self.render_games()

    def use_game(self, game):
        self.set_place(game["place"])
        self.remember_game(game)
        self.toast(f"Place ID set to {game['place']}", "ok")

    def play_game(self, game):
        ids = self.launch_ids()
        if not ids:
            self.toast("Select accounts in the Accounts tab or pick one under Launch as", "error")
            return
        self.set_place(game["place"])
        self.remember_game(game)
        self.log(f"Playing {game['name']} ({game['place']})")
        self.start_launch(ids, game["place"], self.job_text)

    def roblox_page(self):
        t = self.t
        c = self.content
        c.grid_rowconfigure(1, weight=1)
        self.page_header(c, "download", "Roblox", "Install, update and uninstall the Roblox player")
        scroll = ctk.CTkScrollableFrame(
            c,
            fg_color="transparent",
            corner_radius=0,
            scrollbar_button_color=t["border"],
            scrollbar_button_hover_color=t["muted"],
        )
        scroll.grid(row=1, column=0, sticky="nsew")

        versions = installer.installed_versions()
        status = self.card(scroll)
        status.pack(fill="x", pady=(0, 10))
        self.settings_heading(status, "info", "Status", "What is installed on this computer right now.")
        body = ctk.CTkFrame(status, fg_color="transparent")
        body.pack(fill="x", padx=20, pady=(0, 16))
        self.info_row(body, "Roblox player", "Installed" if versions else "Not installed")
        self.info_row(body, "Version", versions[0].name if versions else "-")
        self.info_row(body, "Location", str(installer.versions_dir()))

        install = self.card(scroll)
        install.pack(fill="x", pady=(0, 10))
        self.settings_heading(
            install, "download", "Install", "Downloads the player straight from the Roblox CDN, the same source rdd.weao.gg uses."
        )
        body = ctk.CTkFrame(install, fg_color="transparent")
        body.pack(fill="x", padx=20, pady=(0, 16))
        self.label(body, "VERSION", 9, True, t["muted"], anchor="w").pack(fill="x", padx=4)
        self.version_entry = self.entry(body, "version-...")
        self.version_entry.pack(fill="x", pady=(4, 10))
        self.version_entry.insert(0, self.store.settings["roblox_version"])
        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x")
        installing = self.install_state["running"]
        label = "Reinstall" if versions else "Install"
        install_button = self.button(row, label, icon="download", primary=True, command=self.start_install, width=120)
        install_button.pack(side="left")
        cancel_button = self.button(row, "Cancel", command=self.cancel_install, width=90)
        cancel_button.pack(side="left", padx=(8, 0))
        self.button(row, "Latest version", icon="refresh", command=self.fetch_latest, width=130).pack(side="left", padx=8)
        self.button(row, "Open RDD page", icon="globe", command=self.open_rdd, width=130).pack(side="left")
        bar = ctk.CTkProgressBar(
            body, height=8, corner_radius=4, fg_color=t["field"], progress_color=t["accent"]
        )
        bar.pack(fill="x", pady=(14, 6))
        bar.set(self.install_state["value"])
        text = self.label(body, self.install_state["text"], 11, False, t["muted"], anchor="w")
        text.pack(fill="x", padx=4)
        self.install_widgets = {"bar": bar, "text": text, "install": install_button, "cancel": cancel_button}
        self.sync_install()

        remove = self.card(scroll)
        remove.pack(fill="x")
        self.settings_heading(
            remove, "trash", "Uninstall", "Removes every Roblox player version from this computer. Your accounts stay in Vibes Manager."
        )
        body = ctk.CTkFrame(remove, fg_color="transparent")
        body.pack(fill="x", padx=20, pady=(0, 16))
        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x")
        self.button(row, "Uninstall Roblox", icon="trash", danger=True, command=self.confirm_uninstall, width=150).pack(
            side="left"
        )
        self.button(row, "Open folder", icon="folder", command=self.open_roblox_folder, width=120).pack(side="left", padx=8)

    def sync_install(self):
        widgets = self.install_widgets
        if not widgets:
            return
        state = self.install_state
        try:
            widgets["bar"].set(state["value"])
            widgets["text"].configure(text=state["text"])
            widgets["install"].configure(state="disabled" if state["running"] else "normal")
            widgets["cancel"].configure(state="normal" if state["running"] else "disabled")
        except Exception:
            self.install_widgets = {}

    def start_install(self):
        if self.install_state["running"]:
            return
        version = installer.normalize_version(self.version_entry.get())
        self.store.settings["roblox_version"] = version
        self.store.save_settings()
        cancel = threading.Event()
        self.install_state.update(running=True, value=0.0, text="Starting...", cancel=cancel)
        self.sync_install()
        self.log(f"Installing Roblox {version}")
        threading.Thread(target=self._install_worker, args=(version, cancel), daemon=True).start()

    def _install_worker(self, version, cancel):
        last = [0.0]

        def callback(value, text):
            now = time.time()
            if now - last[0] < 0.15 and value < 0.97:
                return
            last[0] = now
            self.ui(self._install_progress, value, text)

        try:
            installer.install(version, "LIVE", callback, cancel)
        except installer.Cancelled:
            self.ui(self._install_done, False, "Installation cancelled")
        except installer.InstallError as error:
            self.ui(self._install_done, False, str(error))
        except Exception:
            log_error()
            self.ui(self._install_done, False, "Installation failed")
        else:
            self.ui(self._install_done, True, f"Installed {version}")

    def _install_progress(self, value, text):
        if not self.install_state["running"]:
            return
        self.install_state.update(value=value, text=f"{text}  ({int(value * 100)}%)")
        self.sync_install()

    def _install_done(self, ok, message):
        self.install_state.update(running=False, value=1.0 if ok else 0.0, text=message, cancel=None)
        self.log(message)
        self.toast(message, "ok" if ok else "error")
        if self.page == "roblox":
            self.build()

    def cancel_install(self):
        cancel = self.install_state.get("cancel")
        if cancel is not None:
            cancel.set()
            self.install_state["text"] = "Cancelling..."
            self.sync_install()

    def fetch_latest(self):
        def work():
            try:
                version = installer.latest_version()
            except installer.InstallError as error:
                self.ui(self.toast, str(error), "error")
                return
            self.ui(self._set_version, version)

        threading.Thread(target=work, daemon=True).start()

    def _set_version(self, version):
        try:
            self.version_entry.delete(0, "end")
            self.version_entry.insert(0, version)
        except Exception:
            pass
        self.toast(f"Latest version is {version}", "ok")

    def open_rdd(self):
        version = installer.normalize_version(self.version_entry.get())
        webbrowser.open(installer.RDD_URL.format(version=version))

    def confirm_uninstall(self):
        if not installer.is_installed():
            self.toast("Roblox is not installed", "error")
            return
        ConfirmDialog(
            self,
            "Uninstall Roblox",
            "This closes running Roblox windows and deletes every installed player version.",
            self.start_uninstall,
            "Uninstall",
        )

    def start_uninstall(self):
        self.toast("Uninstalling Roblox...")
        self.log("Uninstalling Roblox")
        threading.Thread(target=self._uninstall_worker, daemon=True).start()

    def _uninstall_worker(self):
        removed, failed = installer.uninstall()
        self.ui(self._uninstall_done, removed, failed)

    def _uninstall_done(self, removed, failed):
        if failed:
            message = f"Could not remove {len(failed)} version(s). Close Roblox and try again"
            self.toast(message, "error")
        else:
            message = f"Roblox uninstalled ({removed} version" + ("s" if removed != 1 else "") + " removed)"
            self.toast(message, "ok")
        self.log(message)
        self.install_state.update(value=0.0, text="")
        if self.page == "roblox":
            self.build()

    def open_roblox_folder(self):
        folder = installer.versions_dir()
        if not folder.exists():
            folder = installer.roblox_dir()
        if not folder.exists():
            self.toast("Roblox folder does not exist", "error")
            return
        self.open_path(str(folder))

    def open_path(self, path):
        try:
            if os.name == "nt":
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception:
            self.toast("Could not open the folder", "error")

    def logs_page(self):
        t = self.t
        c = self.content
        c.grid_rowconfigure(1, weight=1)
        header = self.page_header(c, "list", "Logs", "Activity from this session")
        self.small_button(header, "Copy", "check_all", self.copy_logs).grid(row=0, column=2, rowspan=2, padx=4)
        self.small_button(header, "Clear", "close", self.clear_logs).grid(row=0, column=3, rowspan=2, padx=(4, 16))
        card = self.card(c)
        card.grid(row=1, column=0, sticky="nsew")
        self.log_box = ctk.CTkTextbox(
            card,
            fg_color=t["field"],
            text_color=t["text"],
            corner_radius=12,
            font=ctk.CTkFont(family="Consolas", size=11),
        )
        self.log_box.pack(fill="both", expand=True, padx=12, pady=12)
        if self.log_lines:
            self.log_box.insert("1.0", "\n".join(self.log_lines) + "\n")
            self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def copy_logs(self):
        self.clipboard_clear()
        self.clipboard_append("\n".join(self.log_lines))
        self.toast("Logs copied", "ok")

    def clear_logs(self):
        self.log_lines = []
        if self.log_box is not None:
            self.log_box.configure(state="normal")
            self.log_box.delete("1.0", "end")
            self.log_box.configure(state="disabled")

    def settings_page(self):
        t = self.t
        c = self.content
        c.grid_rowconfigure(1, weight=1)
        self.page_header(c, "settings", "Settings", "Themes, launcher behaviour and data")
        scroll = ctk.CTkScrollableFrame(
            c,
            fg_color="transparent",
            corner_radius=0,
            scrollbar_button_color=t["border"],
            scrollbar_button_hover_color=t["muted"],
        )
        scroll.grid(row=1, column=0, sticky="nsew")

        appearance = self.card(scroll)
        appearance.pack(fill="x", pady=(0, 10))
        self.settings_heading(appearance, "palette", "Appearance", "Pick a theme. It applies instantly.")
        grid = ctk.CTkFrame(appearance, fg_color="transparent")
        grid.pack(fill="x", padx=16, pady=(0, 16))
        for index, (name, theme) in enumerate(THEMES.items()):
            selected = self.store.settings["theme"] == name
            tile = ctk.CTkFrame(
                grid,
                fg_color=theme["bg"],
                corner_radius=14,
                border_width=3 if selected else 1,
                border_color=theme["accent"] if selected else theme["border"],
                width=120,
                height=76,
            )
            tile.grid(row=index // 5, column=index % 5, padx=5, pady=5)
            tile.grid_propagate(False)
            tile.pack_propagate(False)
            ctk.CTkButton(
                tile,
                text=name,
                font=F(12, True),
                height=30,
                corner_radius=12,
                fg_color="transparent",
                hover_color=theme["card"],
                text_color=theme["text"],
                command=lambda n=name: self.set_theme(n),
            ).pack(fill="x", padx=6, pady=(8, 2))
            swatches = ctk.CTkFrame(tile, fg_color="transparent")
            swatches.pack(pady=(2, 0))
            for color in (theme["card"], theme["row"], theme["accent"]):
                ctk.CTkFrame(
                    swatches, width=24, height=12, corner_radius=6, fg_color=color, border_width=1, border_color=theme["border"]
                ).pack(side="left", padx=2)

        launcher = self.card(scroll)
        launcher.pack(fill="x", pady=(0, 10))
        self.settings_heading(launcher, "sliders", "Launcher", "Control how accounts are started and refreshed.")
        body = ctk.CTkFrame(launcher, fg_color="transparent")
        body.pack(fill="x", padx=22, pady=(0, 16))
        delay_row = ctk.CTkFrame(body, fg_color="transparent")
        delay_row.pack(fill="x", pady=4)
        self.label(delay_row, "Delay between launches", 13, True).pack(side="left")
        delay_value = self.label(delay_row, f"{self.store.settings['launch_delay']}s", 13, True, t["muted"])
        delay_value.pack(side="right")

        def on_delay(value):
            self.store.settings["launch_delay"] = int(value)
            delay_value.configure(text=f"{int(value)}s")
            self.store.save_settings()
            self.update_hint()

        slider = ctk.CTkSlider(
            body,
            from_=0,
            to=30,
            number_of_steps=30,
            command=on_delay,
            progress_color=t["accent"],
            button_color=t["accent"],
            button_hover_color=t["accent_hover"],
            fg_color=t["field"],
        )
        slider.set(self.store.settings["launch_delay"])
        slider.pack(fill="x", pady=(4, 8))
        self.switch(body, "Refresh accounts when the app starts", "auto_refresh")
        self.switch(body, "Ask before removing accounts", "confirm_delete")
        self.switch(body, "Allow several Roblox windows at once", "multi_instance")

        data = self.card(scroll)
        data.pack(fill="x", pady=(0, 10))
        self.settings_heading(data, "lock", "Data and security", "Everything is stored locally and encrypted.")
        body = ctk.CTkFrame(data, fg_color="transparent")
        body.pack(fill="x", padx=22, pady=(0, 16))
        license_info = licensing.info()
        self.info_row(body, "License", license_info.get("masked", "-"))
        self.info_row(body, "Data folder", str(data_dir()))
        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.pack(fill="x", pady=(10, 0))
        self.button(buttons, "Open data folder", icon="folder", command=lambda: self.open_path(str(data_dir())), width=150).pack(
            side="left"
        )
        self.button(
            buttons, "Remove all accounts", icon="trash", danger=True, command=self.remove_all, width=170
        ).pack(side="left", padx=8)

        about = self.card(scroll)
        about.pack(fill="x")
        self.settings_heading(about, "info", "About", "Vibes Manager")
        body = ctk.CTkFrame(about, fg_color="transparent")
        body.pack(fill="x", padx=22, pady=(0, 16))
        self.info_row(body, "Version", VERSION)
        self.info_row(body, "Roblox client", "Installed" if roblox.installed() else "Not found")
        self.info_row(body, "Accounts", str(len(self.store.accounts)))

    def settings_heading(self, parent, icon, title, subtitle):
        t = self.t
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(14, 10))
        ctk.CTkLabel(
            row,
            text="",
            image=self.icon(icon, 16, t["text"]),
            width=34,
            height=34,
            corner_radius=11,
            fg_color=t["field"],
        ).pack(side="left")
        text = ctk.CTkFrame(row, fg_color="transparent")
        text.pack(side="left", padx=12)
        self.label(text, title, 14, True, anchor="w").pack(anchor="w")
        self.label(text, subtitle, 11, False, t["muted"], anchor="w", justify="left", wraplength=620).pack(anchor="w")

    def info_row(self, parent, name, value):
        t = self.t
        row = ctk.CTkFrame(parent, fg_color=t["row"], corner_radius=14, height=34)
        row.pack(fill="x", pady=3)
        row.pack_propagate(False)
        self.label(row, name, 12, True).pack(side="left", padx=14)
        self.label(row, value, 11, False, t["muted"]).pack(side="right", padx=14)

    def switch(self, parent, text, key):
        t = self.t
        var = ctk.BooleanVar(value=bool(self.store.settings[key]))

        def toggle():
            self.store.settings[key] = bool(var.get())
            self.store.save_settings()

        ctk.CTkSwitch(
            parent,
            text=text,
            variable=var,
            command=toggle,
            font=F(12),
            text_color=t["text"],
            progress_color=t["good"],
            button_color=t["text"],
            button_hover_color=t["muted"],
            fg_color=t["border"],
        ).pack(anchor="w", pady=6)

    def set_theme(self, name):
        self.store.settings["theme"] = name
        self.store.save_settings()
        self._icons = {}
        self.game_icon_images = {}
        self.build()

    def remove_all(self):
        if not self.store.accounts:
            self.toast("There are no accounts to remove", "error")
            return

        def go():
            self.store.clear()
            self.sel.clear()
            self.build()
            self.log("Removed all accounts")
            self.toast("All accounts removed", "ok")

        ConfirmDialog(self, "Remove all accounts", "This deletes every stored account and cookie from this computer.", go, "Remove all")
