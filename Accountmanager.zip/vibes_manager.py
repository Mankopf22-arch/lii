import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from vibes import console


def start_gui():
    from vibes import licensing

    environment = dict(os.environ)
    environment["VIBES_SESSION"] = licensing.session_token()
    target = str(ROOT / "vibes_gui.py")
    executable = sys.executable
    if os.name == "nt":
        pythonw = Path(executable).with_name("pythonw.exe")
        if pythonw.exists():
            executable = str(pythonw)
        flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
        subprocess.Popen([executable, target], creationflags=flags, env=environment, cwd=str(ROOT), close_fds=True)
    else:
        subprocess.Popen(
            [executable, target],
            env=environment,
            cwd=str(ROOT),
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )


def main():
    console.enable()
    console.banner("Vibes Manager")
    try:
        from vibes import licensing
    except ImportError:
        console.fail("Requirements are missing. Run setup first")
        console.pause(3)
        sys.exit(1)

    if not licensing.is_activated():
        console.fail("No license found. Run setup first")
        console.pause(3)
        sys.exit(1)

    console.ok("License verified")
    console.info("Opening Vibes Manager")
    console.pause(0.8)
    start_gui()
    sys.exit(0)

if __name__ == "__main__":
    main()
