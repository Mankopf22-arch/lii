import queue
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import customtkinter as ctk

from . import roblox
from .dialogs import AddAccountDialog, GroupsDialog
from .pages import PagesMixin
from .paths import data_dir
from .storage import Store
from .themes import THEMES
from .ui import (
    ConfirmDialog,
    F,
    Pills,
    circle_image,
    log_error,
    placeholder_circle,
    placeholder_square,
    render,
    rounded_image,
    short,
)

PRESENCE = {0: "Offline", 1: "Online", 2: "In game", 3: "Studio"}
NAV = (
    ("accounts", "users", "Accounts"),
    ("games", "grid", "Games"),
    ("roblox", "download", "Roblox"),
    ("logs", "list", "Logs"),
    ("settings", "settings", "Settings"),
)
MAX_LOG = 500


class App(PagesMixin, ctk.CTk):
    def __init__(self):
        super().__init__()
        self.store = Store()
        self.title("Vibes Manager")
        self.geometry("980x620")
        self.minsize(900, 560)
        self.q = queue.Queue()
        self.page = "accounts"
        self.status_filter = "All"
        self.group_filter = "All"
        self.search_text = ""
        self.job_text = ""
        self.sel = {}
        self.avatar_images = {}
        self.avatar_labels = {}
        self.avatar_pending = set()
        self._icons = {}
        self.game = None
        self.game_icon_image = None
        self.game_widgets = {}
        self.game_query = ""
        self.game_results = None
        self.game_icon_bytes = {}
        self.game_busy = False
        self.game_list = None
        self.game_entry = None
        self.game_icon_images = {}
        self.icons_pending = set()
        self.launch_as = ctk.StringVar(value="Selected accounts")
        self.install_state = {"running": False, "value": 0.0, "text": "", "cancel": None}
        self.install_widgets = {}
        self.log_lines = []
        self.log_box = None
        self._toast = None
        self._toast_job = None
        self._place_job = None
        self._place_token = 0
        self._search_job = None
        self.refreshing = False
        self.shell = None
        self.list_frame = None
        self.count_label = None
        self.build()
        self.after(40, self._pump)
        self.log("Vibes Manager started")
        self.fetch_place(self.store.settings["place_id"])
        self.ensure_avatars()
        if self.store.settings["auto_refresh"] and self.store.accounts:
            self.after(900, self.refresh_all)

    @property
    def t(self):
        return THEMES.get(self.store.settings["theme"], THEMES["Rift"])

    def ui(self, fn, *args):
        self.q.put((fn, args))

    def _pump(self):
        try:
            while True:
                fn, args = self.q.get_nowait()
                try:
                    fn(*args)
                except Exception:
                    log_error()
        except queue.Empty:
            pass
        self.after(40, self._pump)

    def log(self, message):
        line = time.strftime("%H:%M:%S") + "  " + message
        self.log_lines.append(line)
        if len(self.log_lines) > MAX_LOG:
            self.log_lines = self.log_lines[-MAX_LOG:]
        try:
            with open(data_dir() / "activity.log", "a", encoding="utf-8") as handle:
                handle.write(time.strftime("%Y-%m-%d ") + line + "\n")
        except OSError:
            pass
        self.ui(self._log_view, line)

    def _log_view(self, line):
        if self.log_box is None:
            return
        try:
            self.log_box.configure(state="normal")
            self.log_box.insert("end", line + "\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        except Exception:
            self.log_box = None

    def icon(self, name, size=16, color=None):
        color = color or self.t["text"]
        key = (name, size, color)
        if key not in self._icons:
            image = render(name, size * 2, color)
            self._icons[key] = ctk.CTkImage(light_image=image, dark_image=image, size=(size, size))
        return self._icons[key]

    def card(self, parent, **kwargs):
        t = self.t
        return ctk.CTkFrame(
            parent, fg_color=t["card"], corner_radius=18, border_width=1, border_color=t["border"], **kwargs
        )

    def button(self, parent, text, icon=None, primary=False, command=None, width=None, height=34, size=12, danger=False):
        t = self.t
        if primary:
            fg, hover, color = t["accent"], t["accent_hover"], t["accent_text"]
        elif danger:
            fg, hover, color = t["field"], t["row"], t["bad"]
        else:
            fg, hover, color = t["field"], t["row"], t["text"]
        options = {
            "text": text,
            "height": height,
            "corner_radius": height // 2,
            "font": F(size, True),
            "command": command,
            "fg_color": fg,
            "hover_color": hover,
            "text_color": color,
            "compound": "left",
        }
        if icon:
            options["image"] = self.icon(icon, 15, color)
        if width:
            options["width"] = width
        return ctk.CTkButton(parent, **options)

    def small_button(self, parent, text, icon, command, danger=False):
        t = self.t
        color = t["bad"] if danger else t["text"]
        return ctk.CTkButton(
            parent,
            text=text,
            image=self.icon(icon, 14, color),
            compound="left",
            height=28,
            width=max(64, len(text) * 7 + 44),
            corner_radius=14,
            font=F(11, True),
            fg_color=t["field"],
            hover_color=t["row"],
            text_color=color,
            command=command,
        )

    def entry(self, parent, placeholder, height=34):
        t = self.t
        return ctk.CTkEntry(
            parent,
            placeholder_text=placeholder,
            fg_color=t["field"],
            border_width=0,
            text_color=t["text"],
            placeholder_text_color=t["muted"],
            corner_radius=16,
            height=height,
            font=F(12),
        )

    def label(self, parent, text, size=12, bold=False, color=None, **kwargs):
        return ctk.CTkLabel(parent, text=text, font=F(size, bold), text_color=color or self.t["text"], **kwargs)

    def section_title(self, parent, text):
        return self.label(parent, text, 10, True, self.t["muted"], anchor="w")

    def page_header(self, parent, icon, title, subtitle):
        t = self.t
        header = self.card(parent)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        header.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(
            header,
            text="",
            image=self.icon(icon, 20, t["text"]),
            width=44,
            height=44,
            corner_radius=14,
            fg_color=t["field"],
        ).grid(row=0, column=0, rowspan=2, padx=(16, 12), pady=14)
        self.label(header, title, 18, True, anchor="w").grid(row=0, column=1, sticky="sw", pady=(14, 0))
        self.label(header, subtitle, 12, False, t["muted"], anchor="w").grid(row=1, column=1, sticky="nw", pady=(0, 14))
        return header

    def build(self):
        t = self.t
        ctk.set_appearance_mode(t["mode"])
        self.configure(fg_color=t["bg"])
        if self.shell is not None:
            self.shell.destroy()
        self.avatar_labels = {}
        self.game_widgets = {}
        self.install_widgets = {}
        self.game_list = None
        self.game_entry = None
        self.list_frame = None
        self.count_label = None
        self.log_box = None
        self._toast = None
        self.shell = ctk.CTkFrame(self, fg_color=t["bg"], corner_radius=0)
        self.shell.pack(fill="both", expand=True)
        self.shell.grid_columnconfigure(1, weight=1)
        self.shell.grid_rowconfigure(0, weight=1)
        self.build_sidebar()
        self.content = ctk.CTkFrame(self.shell, fg_color="transparent")
        self.content.grid(row=0, column=1, sticky="nsew", padx=(4, 12), pady=12)
        self.content.grid_columnconfigure(0, weight=1)
        pages = {
            "accounts": self.accounts_page,
            "games": self.games_page,
            "roblox": self.roblox_page,
            "logs": self.logs_page,
            "settings": self.settings_page,
        }
        pages[self.page]()
        if self.page == "accounts":
            self.render_accounts()
            self.update_game_card()

    def show(self, page):
        self.page = page
        self.build()

    def build_sidebar(self):
        t = self.t
        bar = ctk.CTkFrame(self.shell, fg_color=t["sidebar"], corner_radius=20, width=76)
        bar.grid(row=0, column=0, sticky="ns", padx=(12, 4), pady=12)
        bar.grid_propagate(False)
        ctk.CTkLabel(
            bar,
            text="V",
            width=36,
            height=36,
            corner_radius=12,
            fg_color=t["accent"],
            text_color=t["accent_text"],
            font=F(16, True),
        ).pack(padx=20, pady=(16, 14))
        for page, icon_name, title in NAV:
            active = self.page == page
            ctk.CTkButton(
                bar,
                text=title,
                image=self.icon(icon_name, 18, t["accent_text"] if active else t["muted"]),
                compound="top",
                width=62,
                height=50,
                corner_radius=14,
                font=F(10, True),
                text_color=t["accent_text"] if active else t["muted"],
                fg_color=t["accent"] if active else "transparent",
                hover_color=t["accent"] if active else t["row"],
                command=lambda p=page: self.show(p),
            ).pack(padx=7, pady=3)

    def accounts_page(self):
        t = self.t
        c = self.content
        c.grid_rowconfigure(2, weight=1)
        c.grid_columnconfigure(0, weight=1)

        header = self.page_header(c, "users", "Accounts", "Manage, filter and launch your accounts")
        self.button(header, "Refresh", icon="refresh", command=self.refresh_all, width=100).grid(
            row=0, column=2, rowspan=2, padx=4
        )
        self.button(
            header, "Add account", icon="user_plus", primary=True, command=lambda: AddAccountDialog(self), width=130
        ).grid(row=0, column=3, rowspan=2, padx=(4, 16))

        filters = self.card(c)
        filters.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        top = ctk.CTkFrame(filters, fg_color="transparent")
        top.pack(fill="x", padx=14, pady=(12, 6))
        box = ctk.CTkFrame(top, fg_color=t["field"], corner_radius=18, height=36)
        box.pack(side="left", fill="x", expand=True)
        box.pack_propagate(False)
        ctk.CTkLabel(box, text="", image=self.icon("search", 15, t["muted"])).pack(side="left", padx=(12, 2))
        search = ctk.CTkEntry(
            box,
            placeholder_text="Search accounts...",
            fg_color="transparent",
            border_width=0,
            text_color=t["text"],
            placeholder_text_color=t["muted"],
            height=34,
            font=F(12),
        )
        search.pack(side="left", fill="x", expand=True, padx=(0, 10))
        if self.search_text:
            search.insert(0, self.search_text)
        search.bind("<KeyRelease>", lambda event, e=search: self.on_search(e))
        Pills(top, self, ["All", "Valid", "Invalid", "Banned"], self.status_filter, self.set_status).pack(
            side="left", padx=(10, 0)
        )

        bottom = ctk.CTkFrame(filters, fg_color="transparent")
        bottom.pack(fill="x", padx=14, pady=(0, 12))
        self.label(bottom, "GROUP", 9, True, t["muted"]).pack(side="left", padx=(4, 8))
        groups = ["All"] + self.store.groups
        if self.group_filter not in groups:
            self.group_filter = "All"
        Pills(bottom, self, groups, self.group_filter, self.set_group, height=24, font_size=11).pack(side="left")
        self.small_button(bottom, "Groups", "folder", lambda: GroupsDialog(self)).pack(side="right")
        self.small_button(bottom, "Remove", "trash", self.remove_selected, danger=True).pack(side="right", padx=6)
        self.small_button(bottom, "Clear", "close", self.clear_selection).pack(side="right")
        self.small_button(bottom, "All", "check_all", self.select_all).pack(side="right", padx=6)

        body = ctk.CTkFrame(c, fg_color="transparent")
        body.grid(row=2, column=0, sticky="nsew")
        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(0, weight=1)

        left = self.card(body)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        head = ctk.CTkFrame(left, fg_color="transparent")
        head.pack(fill="x", padx=18, pady=(12, 2))
        self.section_title(head, "ACCOUNTS").pack(side="left")
        self.count_label = self.label(head, "", 11, False, t["muted"])
        self.count_label.pack(side="right")
        self.list_frame = ctk.CTkScrollableFrame(
            left,
            fg_color="transparent",
            corner_radius=0,
            scrollbar_button_color=t["border"],
            scrollbar_button_hover_color=t["muted"],
        )
        self.list_frame.pack(fill="both", expand=True, padx=(10, 4), pady=(0, 10))

        right = self.card(body, width=290)
        right.grid(row=0, column=1, sticky="nsew")
        right.pack_propagate(False)
        self.launcher_panel(right)

    def on_search(self, source):
        self.search_text = source.get()
        if self._search_job:
            self.after_cancel(self._search_job)
        self._search_job = self.after(160, self.apply_search)

    def apply_search(self):
        self._search_job = None
        if self.page == "accounts":
            self.render_accounts()

    def launcher_panel(self, panel):
        t = self.t
        self.section_title(panel, "LAUNCHER").pack(fill="x", padx=18, pady=(14, 8))
        self.label(panel, "PLACE ID", 9, True, t["muted"], anchor="w").pack(fill="x", padx=20)
        self.place_entry = self.entry(panel, "Place ID")
        self.place_entry.pack(fill="x", padx=16, pady=(4, 10))
        if self.store.settings["place_id"]:
            self.place_entry.insert(0, self.store.settings["place_id"])
        self.place_entry.bind("<KeyRelease>", lambda event: self.on_place_change())

        game = ctk.CTkFrame(panel, fg_color=t["row"], corner_radius=16)
        game.pack(fill="x", padx=16)
        top = ctk.CTkFrame(game, fg_color="transparent")
        top.pack(fill="x", padx=10, pady=(10, 6))
        icon_label = ctk.CTkLabel(top, text="", width=48, height=48)
        icon_label.pack(side="left")
        name_label = self.label(top, "No game selected", 12, True, anchor="w", justify="left", wraplength=170)
        name_label.pack(side="left", padx=10, fill="x", expand=True)
        stats = ctk.CTkFrame(game, fg_color="transparent")
        stats.pack(fill="x", padx=10, pady=(0, 10))
        values = {}
        for index, (key, title) in enumerate((("playing", "ONLINE"), ("favorites", "FAVORITES"), ("likes", "LIKES"))):
            stats.grid_columnconfigure(index, weight=1)
            cell = ctk.CTkFrame(stats, fg_color="transparent")
            cell.grid(row=0, column=index, sticky="w")
            self.label(cell, title, 8, True, t["muted"], anchor="w").pack(anchor="w")
            value = self.label(cell, "-", 13, True, anchor="w")
            value.pack(anchor="w")
            values[key] = value
        self.game_widgets = {"icon": icon_label, "name": name_label, "values": values}

        self.label(panel, "JOB ID (OPTIONAL)", 9, True, t["muted"], anchor="w").pack(fill="x", padx=20, pady=(12, 0))
        self.job_entry = self.entry(panel, "Job ID (optional)")
        self.job_entry.pack(fill="x", padx=16, pady=(4, 12))
        if self.job_text:
            self.job_entry.insert(0, self.job_text)
        self.job_entry.bind("<KeyRelease>", lambda event: setattr(self, "job_text", self.job_entry.get()))

        self.button(panel, "Launch selected", icon="play", primary=True, command=self.launch_selected, height=40, size=13).pack(
            fill="x", padx=16
        )
        self.launch_hint = self.label(panel, "", 11, False, t["muted"], anchor="w", wraplength=250, justify="left")
        self.launch_hint.pack(fill="x", padx=20, pady=(10, 0))
        self.update_hint()

    def update_hint(self):
        try:
            count = len(self.selected_ids())
            self.launch_hint.configure(
                text=f"{count} account" + ("s" if count != 1 else "") + f" selected. Delay between launches: {self.store.settings['launch_delay']}s"
            )
        except Exception:
            pass

    def set_status(self, value):
        self.status_filter = value
        self.render_accounts()

    def set_group(self, value):
        self.group_filter = value
        self.render_accounts()

    def var_for(self, account_id):
        if account_id not in self.sel:
            self.sel[account_id] = ctk.BooleanVar(value=False)
        return self.sel[account_id]

    def selected_ids(self):
        return [a["id"] for a in self.store.accounts if a["id"] in self.sel and self.sel[a["id"]].get()]

    def visible_accounts(self):
        query = self.search_text.strip().lower()
        result = []
        for account in self.store.accounts:
            if self.status_filter != "All" and account["status"] != self.status_filter.lower():
                continue
            if self.group_filter != "All" and account["group"] != self.group_filter:
                continue
            if query and query not in account["name"].lower() and query not in str(account["id"]) and query not in account.get("display", "").lower():
                continue
            result.append(account)
        return result

    def select_all(self):
        for account in self.visible_accounts():
            self.var_for(account["id"]).set(True)
        self.update_hint()

    def clear_selection(self):
        for var in self.sel.values():
            var.set(False)
        self.update_hint()

    def remove_selected(self):
        ids = self.selected_ids()
        if not ids:
            self.toast("Select accounts first", "error")
            return
        self.delete_accounts(ids)

    def delete_accounts(self, ids):
        def go():
            self.store.remove(ids)
            for account_id in ids:
                self.sel.pop(account_id, None)
            self.render_accounts()
            self.update_hint()
            self.log(f"Removed {len(ids)} account(s)")
            self.toast(f"Removed {len(ids)} account" + ("s" if len(ids) != 1 else ""), "ok")

        if self.store.settings["confirm_delete"]:
            ConfirmDialog(
                self,
                "Remove accounts",
                f"Remove {len(ids)} account" + ("s" if len(ids) != 1 else "") + " from Vibes Manager? Cookies will be deleted from this computer.",
                go,
                "Remove",
            )
        else:
            go()

    def render_accounts(self):
        if self.page != "accounts" or self.list_frame is None:
            return
        t = self.t
        for widget in self.list_frame.winfo_children():
            widget.destroy()
        self.avatar_labels = {}
        accounts = self.visible_accounts()
        total = len(self.store.accounts)
        valid = sum(1 for a in self.store.accounts if a["status"] == "valid")
        self.count_label.configure(text=f"{total} · {valid} valid")
        if not accounts:
            message = "No accounts yet. Use Add account to get started." if total == 0 else "No accounts match your filters."
            self.label(self.list_frame, message, 12, False, t["muted"]).pack(pady=30)
            return
        for account in accounts:
            self.account_row(account)

    def avatar_for(self, account_id):
        if account_id in self.avatar_images:
            return self.avatar_images[account_id]
        t = self.t
        image = placeholder_circle(36, t["border"], t["muted"])
        return ctk.CTkImage(light_image=image, dark_image=image, size=(36, 36))

    def account_row(self, account):
        t = self.t
        row = ctk.CTkFrame(self.list_frame, fg_color=t["row"], corner_radius=16, height=54)
        row.pack(fill="x", pady=3, padx=(0, 6))
        row.pack_propagate(False)
        ctk.CTkCheckBox(
            row,
            text="",
            variable=self.var_for(account["id"]),
            width=22,
            checkbox_width=18,
            checkbox_height=18,
            corner_radius=6,
            border_width=2,
            fg_color=t["accent"],
            hover_color=t["accent_hover"],
            border_color=t["muted"],
            checkmark_color=t["accent_text"],
            command=self.update_hint,
        ).pack(side="left", padx=(14, 4))
        avatar = ctk.CTkLabel(row, text="", image=self.avatar_for(account["id"]), width=36, height=36)
        avatar.pack(side="left", padx=(2, 10))
        self.avatar_labels[account["id"]] = avatar

        ctk.CTkButton(
            row,
            text="",
            image=self.icon("play", 14, t["text"]),
            width=30,
            height=30,
            corner_radius=15,
            fg_color=t["field"],
            hover_color=t["border"],
            command=lambda a=account: self.launch_selected(a["id"]),
        ).pack(side="right", padx=(4, 12))
        ctk.CTkButton(
            row,
            text="",
            image=self.icon("trash", 14, t["bad"]),
            width=30,
            height=30,
            corner_radius=15,
            fg_color=t["field"],
            hover_color=t["border"],
            command=lambda a=account: self.delete_accounts([a["id"]]),
        ).pack(side="right", padx=3)

        colors = {"valid": t["good"], "invalid": t["muted"], "banned": t["bad"], "unknown": t["warn"]}
        pill = ctk.CTkFrame(row, fg_color="transparent")
        pill.pack(side="right", padx=(6, 10))
        ctk.CTkFrame(pill, width=7, height=7, corner_radius=4, fg_color=colors.get(account["status"], t["muted"])).pack(
            side="left", padx=(0, 5)
        )
        self.label(pill, account["status"].capitalize(), 11, False, t["text"]).pack(side="left")

        robux = account.get("robux")
        wallet = ctk.CTkFrame(row, fg_color="transparent")
        wallet.pack(side="right", padx=(6, 6))
        ctk.CTkLabel(wallet, text="", image=self.icon("coin", 12, t["muted"])).pack(side="left", padx=(0, 4))
        self.label(wallet, f"{robux:,}" if isinstance(robux, int) else "-", 12, True, t["text"]).pack(side="left")

        info = ctk.CTkFrame(row, fg_color="transparent")
        info.pack(side="left", fill="x", expand=True)
        self.label(info, account["name"], 13, True, anchor="w").pack(fill="x", pady=(8, 0))
        presence = PRESENCE.get(account.get("presence", 0), "Offline")
        self.label(info, f"{presence} · {account['id']} · {account['group']}", 10, False, t["muted"], anchor="w").pack(
            fill="x"
        )

    def ensure_avatars(self):
        missing = [a["id"] for a in self.store.accounts if a["id"] not in self.avatar_images and a["id"] not in self.avatar_pending]
        if not missing:
            return
        self.avatar_pending.update(missing)
        threading.Thread(target=self._avatar_worker, args=(missing,), daemon=True).start()

    def _avatar_worker(self, ids):
        folder = data_dir() / "avatars"
        folder.mkdir(exist_ok=True)
        for account_id in ids:
            path = folder / f"{account_id}.png"
            data = None
            if path.exists():
                try:
                    data = path.read_bytes()
                except OSError:
                    data = None
            if data is None:
                data = roblox.headshot(account_id)
                if data:
                    try:
                        path.write_bytes(data)
                    except OSError:
                        pass
            self.ui(self._set_avatar, account_id, data)

    def _set_avatar(self, account_id, data):
        self.avatar_pending.discard(account_id)
        if not data:
            return
        image = circle_image(data, 36)
        photo = ctk.CTkImage(light_image=image, dark_image=image, size=(36, 36))
        self.avatar_images[account_id] = photo
        label = self.avatar_labels.get(account_id)
        if label is not None:
            try:
                label.configure(image=photo)
            except Exception:
                pass

    def refresh_all(self):
        if self.refreshing:
            return
        if not self.store.accounts:
            self.toast("No accounts to refresh", "error")
            return
        self.refreshing = True
        self.toast("Refreshing accounts...")
        accounts = [{"id": a["id"], "cookie": a["cookie"]} for a in self.store.accounts]
        threading.Thread(target=self._refresh_worker, args=(accounts,), daemon=True).start()

    def _refresh_worker(self, accounts):
        def one(account):
            result = {"id": account["id"]}
            try:
                info = roblox.authenticate(account["cookie"])
            except roblox.RobloxError:
                result["error"] = True
                return result
            if info is None:
                result.update(status="invalid", robux=None, presence=0)
                return result
            banned = roblox.is_banned(info["id"])
            result.update(
                name=info["name"],
                display=info["display"],
                status="banned" if banned else "valid",
                robux=roblox.robux(account["cookie"]),
                presence=roblox.presence(info["id"], account["cookie"]),
            )
            return result

        with ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(one, accounts))
        self.ui(self._refresh_done, results)

    def _refresh_done(self, results):
        failed = 0
        for result in results:
            if result.get("error"):
                failed += 1
                continue
            account_id = result.pop("id")
            self.store.update(account_id, **result)
        self.store.save()
        self.refreshing = False
        self.render_accounts()
        valid = sum(1 for a in self.store.accounts if a["status"] == "valid")
        message = f"Refreshed {len(results) - failed} accounts, {valid} valid"
        if failed:
            message += f", {failed} unreachable"
        self.log(message)
        self.toast(message, "ok" if not failed else "error")

    def on_place_change(self):
        value = self.place_entry.get().strip()
        self.store.settings["place_id"] = value
        self.store.save_settings()
        if self._place_job:
            self.after_cancel(self._place_job)
        self._place_job = self.after(600, lambda: self.fetch_place(value))

    def set_place(self, value):
        self.store.settings["place_id"] = str(value)
        self.store.save_settings()
        self.fetch_place(str(value))

    def fetch_place(self, value):
        self._place_job = None
        if not value or not value.isdigit():
            self.game = None
            self.update_game_card()
            return
        self._place_token += 1
        token = self._place_token

        def work():
            info = roblox.place_info(value)
            self.ui(self._place_loaded, token, info)

        threading.Thread(target=work, daemon=True).start()

    def _place_loaded(self, token, info):
        if token != self._place_token:
            return
        self.game = info
        self.game_icon_image = None
        if info and info.get("icon"):
            try:
                image = rounded_image(info["icon"], 48, 12)
                self.game_icon_image = ctk.CTkImage(light_image=image, dark_image=image, size=(48, 48))
            except Exception:
                self.game_icon_image = None
        self.update_game_card()

    def update_game_card(self):
        widgets = self.game_widgets
        if not widgets:
            return
        t = self.t
        try:
            if self.game_icon_image is None:
                image = placeholder_square(48, t["field"], t["muted"], 12)
                photo = ctk.CTkImage(light_image=image, dark_image=image, size=(48, 48))
                widgets["_placeholder"] = photo
            else:
                photo = self.game_icon_image
            widgets["icon"].configure(image=photo)
            if self.game:
                widgets["name"].configure(text=self.game["name"])
                for key in ("playing", "favorites", "likes"):
                    widgets["values"][key].configure(text=short(self.game.get(key)))
            else:
                widgets["name"].configure(text="No game selected")
                for key in ("playing", "favorites", "likes"):
                    widgets["values"][key].configure(text="-")
        except Exception:
            log_error()

    def launch_selected(self, only=None):
        place = self.place_entry.get().strip() if hasattr(self, "place_entry") and self.page == "accounts" else self.store.settings["place_id"]
        if not place.isdigit():
            self.toast("Enter a valid Place ID", "error")
            return
        ids = [only] if only else self.selected_ids()
        if not ids:
            self.toast("Select at least one account", "error")
            return
        job = self.job_entry.get().strip() if hasattr(self, "job_entry") and self.page == "accounts" else self.job_text
        self.start_launch(ids, place, job)

    def start_launch(self, ids, place, job=""):
        accounts = [dict(self.store.get(i)) for i in ids if self.store.get(i)]
        if not accounts:
            self.toast("Select at least one account", "error")
            return
        delay = int(self.store.settings["launch_delay"])
        multi = bool(self.store.settings["multi_instance"])
        threading.Thread(target=self._launch_worker, args=(accounts, str(place), job, delay, multi), daemon=True).start()

    def _launch_worker(self, accounts, place, job, delay, multi):
        total = len(accounts)
        failures = 0
        for index, account in enumerate(accounts, start=1):
            self.ui(self.toast, f"Launching {account['name']} ({index}/{total})")
            try:
                roblox.launch(account["cookie"], place, job, multi)
                self.log(f"Launched {account['name']} into place {place}")
            except Exception as error:
                failures += 1
                self.log(f"{account['name']}: {error}")
                self.ui(self.toast, f"{account['name']}: {error}", "error")
                time.sleep(1.5)
            if index < total:
                time.sleep(delay)
        if failures == 0:
            self.ui(self.toast, f"Launched {total} account" + ("s" if total != 1 else ""), "ok")

    def toast(self, message, kind="info"):
        t = self.t
        if self._toast is not None:
            try:
                self._toast.destroy()
            except Exception:
                pass
        if self._toast_job:
            try:
                self.after_cancel(self._toast_job)
            except Exception:
                pass
        if kind == "error":
            fg, color = t["bad"], "#14060a"
        elif kind == "ok":
            fg, color = t["good"], "#06140c"
        else:
            fg, color = t["accent"], t["accent_text"]
        frame = ctk.CTkFrame(self.shell, fg_color=fg, corner_radius=16)
        ctk.CTkLabel(frame, text=message, text_color=color, font=F(12, True)).pack(padx=16, pady=7)
        frame.place(relx=0.5, rely=0.98, anchor="s")
        self._toast = frame
        self._toast_job = self.after(3800, self._clear_toast)

    def _clear_toast(self):
        self._toast_job = None
        if self._toast is not None:
            try:
                self._toast.destroy()
            except Exception:
                pass
            self._toast = None


def run():
    app = App()
    app.mainloop()
