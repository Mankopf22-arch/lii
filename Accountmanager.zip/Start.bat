@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py -3 vibes_manager.py) else (python vibes_manager.py)
if errorlevel 1 pause
