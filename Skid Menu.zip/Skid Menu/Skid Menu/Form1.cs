#nullable disable
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Pipes;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;

namespace Skid_Menu
{
    static class Theme
    {
        public static readonly Color Bg = Color.FromArgb(11, 12, 16);
        public static readonly Color Side = Color.FromArgb(16, 18, 24);
        public static readonly Color Card = Color.FromArgb(21, 24, 31);
        public static readonly Color Elevated = Color.FromArgb(30, 34, 43);
        public static readonly Color Input = Color.FromArgb(14, 16, 21);
        public static readonly Color Border = Color.FromArgb(38, 42, 52);
        public static readonly Color Accent = Color.FromArgb(0, 170, 255);
        public static readonly Color Accent2 = Color.FromArgb(86, 110, 255);
        public static readonly Color AccentSoft = Color.FromArgb(22, 58, 84);
        public static readonly Color Green = Color.FromArgb(74, 210, 128);
        public static readonly Color Yellow = Color.FromArgb(240, 190, 70);
        public static readonly Color Red = Color.FromArgb(228, 68, 78);
        public static readonly Color Text = Color.FromArgb(232, 236, 244);
        public static readonly Color Muted = Color.FromArgb(128, 136, 150);
    }

    static class Native
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT { public int Left, Top, Right, Bottom; }

        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);
        [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
        [DllImport("user32.dll")] public static extern bool ReleaseCapture();
        [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

        public static void DarkTitleBar(IntPtr handle)
        {
            try { int v = 1; DwmSetWindowAttribute(handle, 20, ref v, 4); } catch { }
        }

        public static bool GetRobloxRect(out RECT r)
        {
            r = new RECT();
            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    if (p.ProcessName.IndexOf("RobloxPlayerBeta", StringComparison.OrdinalIgnoreCase) >= 0
                        && p.MainWindowHandle != IntPtr.Zero)
                    {
                        if (GetWindowRect(p.MainWindowHandle, out r)) return true;
                    }
                }
                catch { }
            }
            return false;
        }

        public static GraphicsPath Round(Rectangle rc, int radius)
        {
            if (rc.Width < 2 || rc.Height < 2) radius = 0;
            int d = radius * 2;
            var path = new GraphicsPath();
            if (d <= 0)
            {
                path.AddRectangle(rc);
                return path;
            }
            path.AddArc(rc.X, rc.Y, d, d, 180, 90);
            path.AddArc(rc.Right - d, rc.Y, d, d, 270, 90);
            path.AddArc(rc.Right - d, rc.Bottom - d, d, d, 0, 90);
            path.AddArc(rc.X, rc.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    static class Icons
    {
        private static PointF P(RectangleF r, float fx, float fy)
        {
            return new PointF(r.X + r.Width * fx, r.Y + r.Height * fy);
        }

        public static void Draw(Graphics g, string kind, RectangleF r, Color color)
        {
            if (r.Width < 2 || r.Height < 2) return;
            var old = g.SmoothingMode;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using (var pen = new Pen(color, Math.Max(1.5f, r.Width / 10f)))
            using (var br = new SolidBrush(color))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                pen.LineJoin = LineJoin.Round;

                switch (kind)
                {
                    case "home":
                        g.DrawLines(pen, new[] { P(r, .08f, .50f), P(r, .5f, .10f), P(r, .92f, .50f) });
                        g.DrawLines(pen, new[] { P(r, .2f, .42f), P(r, .2f, .90f), P(r, .8f, .90f), P(r, .8f, .42f) });
                        g.DrawLines(pen, new[] { P(r, .42f, .90f), P(r, .42f, .62f), P(r, .58f, .62f), P(r, .58f, .90f) });
                        break;
                    case "code":
                        g.DrawLines(pen, new[] { P(r, .34f, .24f), P(r, .08f, .5f), P(r, .34f, .76f) });
                        g.DrawLines(pen, new[] { P(r, .66f, .24f), P(r, .92f, .5f), P(r, .66f, .76f) });
                        g.DrawLine(pen, P(r, .57f, .18f), P(r, .43f, .82f));
                        break;
                    case "hub":
                        g.DrawRectangle(pen, r.X + r.Width * .10f, r.Y + r.Height * .10f, r.Width * .32f, r.Height * .32f);
                        g.DrawRectangle(pen, r.X + r.Width * .58f, r.Y + r.Height * .10f, r.Width * .32f, r.Height * .32f);
                        g.DrawRectangle(pen, r.X + r.Width * .10f, r.Y + r.Height * .58f, r.Width * .32f, r.Height * .32f);
                        g.FillRectangle(br, r.X + r.Width * .58f, r.Y + r.Height * .58f, r.Width * .32f, r.Height * .32f);
                        break;
                    case "sliders":
                        g.DrawLine(pen, P(r, .08f, .22f), P(r, .92f, .22f));
                        g.DrawLine(pen, P(r, .08f, .50f), P(r, .92f, .50f));
                        g.DrawLine(pen, P(r, .08f, .78f), P(r, .92f, .78f));
                        float k = r.Width * .12f;
                        g.FillEllipse(br, r.X + r.Width * .66f - k, r.Y + r.Height * .22f - k, k * 2, k * 2);
                        g.FillEllipse(br, r.X + r.Width * .30f - k, r.Y + r.Height * .50f - k, k * 2, k * 2);
                        g.FillEllipse(br, r.X + r.Width * .72f - k, r.Y + r.Height * .78f - k, k * 2, k * 2);
                        break;
                    case "play":
                        g.FillPolygon(br, new[] { P(r, .26f, .12f), P(r, .88f, .5f), P(r, .26f, .88f) });
                        break;
                    case "trash":
                        g.DrawLine(pen, P(r, .12f, .22f), P(r, .88f, .22f));
                        g.DrawLines(pen, new[] { P(r, .38f, .22f), P(r, .38f, .10f), P(r, .62f, .10f), P(r, .62f, .22f) });
                        g.DrawLines(pen, new[] { P(r, .22f, .22f), P(r, .28f, .90f), P(r, .72f, .90f), P(r, .78f, .22f) });
                        g.DrawLine(pen, P(r, .42f, .40f), P(r, .42f, .74f));
                        g.DrawLine(pen, P(r, .58f, .40f), P(r, .58f, .74f));
                        break;
                    case "folder":
                        g.DrawPolygon(pen, new[] { P(r, .08f, .20f), P(r, .40f, .20f), P(r, .50f, .34f), P(r, .92f, .34f), P(r, .92f, .84f), P(r, .08f, .84f) });
                        break;
                    case "save":
                        g.DrawPolygon(pen, new[] { P(r, .12f, .12f), P(r, .78f, .12f), P(r, .90f, .24f), P(r, .90f, .88f), P(r, .12f, .88f) });
                        g.DrawRectangle(pen, r.X + r.Width * .30f, r.Y + r.Height * .12f, r.Width * .36f, r.Height * .24f);
                        g.DrawRectangle(pen, r.X + r.Width * .28f, r.Y + r.Height * .56f, r.Width * .44f, r.Height * .32f);
                        break;
                    case "search":
                        g.DrawEllipse(pen, r.X + r.Width * .10f, r.Y + r.Height * .10f, r.Width * .55f, r.Height * .55f);
                        g.DrawLine(pen, P(r, .58f, .58f), P(r, .90f, .90f));
                        break;
                    case "bolt":
                        g.FillPolygon(br, new[] { P(r, .58f, .04f), P(r, .20f, .56f), P(r, .46f, .56f), P(r, .40f, .96f), P(r, .80f, .40f), P(r, .54f, .40f) });
                        break;
                    case "download":
                        g.DrawLine(pen, P(r, .5f, .08f), P(r, .5f, .64f));
                        g.DrawLines(pen, new[] { P(r, .28f, .44f), P(r, .5f, .66f), P(r, .72f, .44f) });
                        g.DrawLines(pen, new[] { P(r, .12f, .66f), P(r, .12f, .88f), P(r, .88f, .88f), P(r, .88f, .66f) });
                        break;
                    case "clock":
                        g.DrawEllipse(pen, r.X + r.Width * .08f, r.Y + r.Height * .08f, r.Width * .84f, r.Height * .84f);
                        g.DrawLines(pen, new[] { P(r, .5f, .26f), P(r, .5f, .5f), P(r, .68f, .62f) });
                        break;
                    case "tag":
                        g.DrawPolygon(pen, new[] { P(r, .10f, .10f), P(r, .55f, .10f), P(r, .90f, .45f), P(r, .55f, .90f), P(r, .10f, .55f) });
                        g.FillEllipse(br, r.X + r.Width * .24f, r.Y + r.Height * .24f, r.Width * .13f, r.Height * .13f);
                        break;
                    case "reset":
                        g.DrawArc(pen, r.X + r.Width * .14f, r.Y + r.Height * .14f, r.Width * .72f, r.Height * .72f, -50, 290);
                        g.DrawLines(pen, new[] { P(r, .50f, .02f), P(r, .72f, .14f), P(r, .52f, .30f) });
                        break;
                }
            }

            g.SmoothingMode = old;
        }
    }

    class IconBox : Control
    {
        public string Kind;
        public Color IconColor;

        public IconBox(string kind, int size, Color color)
        {
            Kind = kind;
            IconColor = color;
            Size = new Size(size, size);
            SetStyle(ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.AllPaintingInWmPaint | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Icons.Draw(e.Graphics, Kind, new RectangleF(0, 0, Width, Height), IconColor);
        }
    }

    static class RobloxExecutor
    {
        private const string PIPE_NAME = "SkidMenuExecutor";

        public static bool Execute(string script)
        {
            try
            {
                using (var pipe = new NamedPipeClientStream(".", PIPE_NAME, PipeDirection.Out))
                {
                    pipe.Connect(2000);
                    byte[] data = Encoding.UTF8.GetBytes(script);
                    pipe.Write(data, 0, data.Length);
                    pipe.Flush();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool Inject()
        {
            try
            {
                using (var pipe = new NamedPipeClientStream(".", PIPE_NAME + "_Inject", PipeDirection.Out))
                {
                    pipe.Connect(2000);
                    byte[] data = Encoding.UTF8.GetBytes("INJECT");
                    pipe.Write(data, 0, data.Length);
                    pipe.Flush();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }

    class DBPanel : Panel
    {
        public DBPanel() { DoubleBuffered = true; }
    }

    class Card : Panel
    {
        public int Radius = 10;
        public Color Line = Theme.Border;
        public Color GradientTo = Color.Empty;
        private Color _fill = Theme.Card;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color Fill
        {
            get { return _fill; }
            set { _fill = value; BackColor = value; Invalidate(); }
        }

        public Card()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Card;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Parent != null ? Parent.BackColor : Theme.Bg);
            if (Width < 4 || Height < 4) return;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            var rc = new Rectangle(0, 0, Width - 1, Height - 1);
            using (var path = Native.Round(rc, Radius))
            {
                if (GradientTo != Color.Empty)
                {
                    var rf = new RectangleF(rc.X, rc.Y, rc.Width, rc.Height);
                    using (var br = new LinearGradientBrush(rf, _fill, GradientTo, 20f))
                        g.FillPath(br, path);
                }
                else
                {
                    using (var br = new SolidBrush(_fill))
                        g.FillPath(br, path);
                }
                if (Line != Color.Transparent)
                    using (var p = new Pen(Line))
                        g.DrawPath(p, path);
            }
        }
    }

    class RoundButton : Button
    {
        public Color Normal = Theme.Elevated;
        public Color Hover = Color.FromArgb(44, 50, 63);
        public int Radius = 8;
        public bool LeftAlign = false;
        public string Icon = null;
        public int IconSize = 16;
        private bool _hot;
        private bool _active;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool Active
        {
            get { return _active; }
            set { _active = value; Invalidate(); }
        }

        public RoundButton()
        {
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            Cursor = Cursors.Hand;
            ForeColor = Color.White;
            Font = new Font("Segoe UI Semibold", 9.5f);
            SetStyle(ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
        }

        protected override void OnMouseEnter(EventArgs e) { _hot = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hot = false; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Parent != null ? Parent.BackColor : BackColor);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rc = new Rectangle(0, 0, Width - 1, Height - 1);
            Color fill = _hot ? Hover : Normal;
            if (fill != Color.Transparent)
            {
                using (var path = Native.Round(rc, Radius))
                using (var br = new SolidBrush(fill))
                    g.FillPath(br, path);
            }

            if (_active)
            {
                using (var br = new SolidBrush(Theme.Accent))
                using (var bar = Native.Round(new Rectangle(0, Height / 2 - 10, 4, 20), 2))
                    g.FillPath(br, bar);
            }

            var flags = TextFormatFlags.NoPadding | TextFormatFlags.SingleLine;
            Size ts = TextRenderer.MeasureText(g, Text, Font, new Size(Width, Height), flags);
            int ico = Icon != null ? IconSize : 0;
            int gap = (Icon != null && !string.IsNullOrEmpty(Text)) ? 10 : 0;
            int startX = LeftAlign ? 18 : Math.Max(8, (Width - (ico + gap + ts.Width)) / 2);

            if (Icon != null)
            {
                Color ic = _active ? Theme.Accent : ForeColor;
                Icons.Draw(g, Icon, new RectangleF(startX, (Height - IconSize) / 2f, IconSize, IconSize), ic);
            }

            var tr = new Rectangle(startX + ico + gap, 0, Math.Max(10, Width - (startX + ico + gap) - 8), Height);
            TextRenderer.DrawText(g, Text, Font, tr, ForeColor,
                flags | TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        }
    }

    class ToggleSwitch : Control
    {
        private bool _checked;
        public event EventHandler CheckedChanged;

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool Checked
        {
            get { return _checked; }
            set
            {
                if (_checked == value) return;
                _checked = value;
                Invalidate();
                if (CheckedChanged != null) CheckedChanged(this, EventArgs.Empty);
            }
        }

        public ToggleSwitch()
        {
            Size = new Size(44, 24);
            Cursor = Cursors.Hand;
            SetStyle(ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
        }

        protected override void OnClick(EventArgs e)
        {
            if (Enabled) Checked = !Checked;
            base.OnClick(e);
        }

        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Parent != null ? Parent.BackColor : BackColor);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Color track = _checked ? Theme.Accent : Color.FromArgb(55, 60, 72);
            if (!Enabled) track = Color.FromArgb(36, 39, 47);
            using (var path = Native.Round(new Rectangle(0, 0, Width - 1, Height - 1), Height / 2 - 1))
            using (var br = new SolidBrush(track))
                g.FillPath(br, path);
            int k = Height - 8;
            int x = _checked ? Width - k - 4 : 4;
            using (var br = new SolidBrush(Enabled ? Color.White : Color.FromArgb(110, 115, 125)))
                g.FillEllipse(br, x, 4, k, k);
        }
    }

    static class Highlighter
    {
        private static readonly Regex Rx = new Regex(
            "(?<c>--[^\\n]*)|(?<s>\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*')|(?<k>\\b(?:and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|true|until|while)\\b)|(?<b>\\b(?:print|game|workspace|script|wait|task|pairs|ipairs|require|Instance|Vector3|CFrame|warn|error|pcall|tostring|tonumber|string|table|math)\\b)|(?<n>\\b\\d+(?:\\.\\d+)?\\b)",
            RegexOptions.Compiled);

        private static bool _busy;

        public static void Apply(RichTextBox rtb)
        {
            if (_busy) return;
            if (!rtb.IsHandleCreated) return;
            _busy = true;
            try
            {
                int ss = rtb.SelectionStart, sl = rtb.SelectionLength;
                Native.SendMessage(rtb.Handle, 0x000B, 0, 0);
                rtb.SelectAll();
                rtb.SelectionColor = Theme.Text;
                foreach (Match m in Rx.Matches(rtb.Text))
                {
                    Color c = Theme.Text;
                    if (m.Groups["c"].Success) c = Color.FromArgb(92, 99, 112);
                    else if (m.Groups["s"].Success) c = Color.FromArgb(152, 195, 121);
                    else if (m.Groups["k"].Success) c = Color.FromArgb(198, 120, 221);
                    else if (m.Groups["b"].Success) c = Color.FromArgb(97, 175, 239);
                    else if (m.Groups["n"].Success) c = Color.FromArgb(209, 154, 102);
                    rtb.Select(m.Index, m.Length);
                    rtb.SelectionColor = c;
                }
                rtb.Select(ss, sl);
                rtb.SelectionColor = Theme.Text;
                Native.SendMessage(rtb.Handle, 0x000B, 1, 0);
                rtb.Invalidate();
            }
            finally { _busy = false; }
        }
    }

    static class Json
    {
        public static object Parse(string s)
        {
            int i = 0;
            return Value(s, ref i);
        }

        public static object Get(Dictionary<string, object> d, string k)
        {
            object v;
            return d != null && d.TryGetValue(k, out v) ? v : null;
        }

        public static string Str(Dictionary<string, object> d, string k)
        {
            return Get(d, k) as string ?? "";
        }

        static void Ws(string s, ref int i)
        {
            while (i < s.Length && char.IsWhiteSpace(s[i])) i++;
        }

        static object Value(string s, ref int i)
        {
            Ws(s, ref i);
            if (i >= s.Length) return null;
            char c = s[i];

            if (c == '{')
            {
                var d = new Dictionary<string, object>();
                i++;
                Ws(s, ref i);
                if (i < s.Length && s[i] == '}') { i++; return d; }
                while (i < s.Length)
                {
                    Ws(s, ref i);
                    string k = Text(s, ref i);
                    Ws(s, ref i);
                    i++;
                    d[k] = Value(s, ref i);
                    Ws(s, ref i);
                    if (i < s.Length && s[i] == ',') { i++; continue; }
                    i++;
                    break;
                }
                return d;
            }

            if (c == '[')
            {
                var l = new List<object>();
                i++;
                Ws(s, ref i);
                if (i < s.Length && s[i] == ']') { i++; return l; }
                while (i < s.Length)
                {
                    l.Add(Value(s, ref i));
                    Ws(s, ref i);
                    if (i < s.Length && s[i] == ',') { i++; continue; }
                    i++;
                    break;
                }
                return l;
            }

            if (c == '"') return Text(s, ref i);

            int st = i;
            while (i < s.Length && ",}]".IndexOf(s[i]) < 0 && !char.IsWhiteSpace(s[i])) i++;
            if (i == st) i++;
            string t = s.Substring(st, i - st);
            return t == "null" ? null : t;
        }

        static string Text(string s, ref int i)
        {
            var sb = new StringBuilder();
            i++;
            while (i < s.Length && s[i] != '"')
            {
                char c = s[i++];
                if (c != '\\') { sb.Append(c); continue; }
                char e = s[i++];
                switch (e)
                {
                    case 'n': sb.Append('\n'); break;
                    case 'r': sb.Append('\r'); break;
                    case 't': sb.Append('\t'); break;
                    case 'b': sb.Append('\b'); break;
                    case 'f': sb.Append('\f'); break;
                    case 'u':
                        sb.Append((char)Convert.ToInt32(s.Substring(i, 4), 16));
                        i += 4;
                        break;
                    default: sb.Append(e); break;
                }
            }
            i++;
            return sb.ToString();
        }
    }

    public class ScriptHubPage : Panel
    {
        public Action<string> OnLog;
        public Action<string> OnLoadToEditor;

        private static readonly HttpClient Http = CreateClient();
        private int _loadId;

        private static HttpClient CreateClient()
        {
            var c = new HttpClient();
            c.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0");
            c.Timeout = TimeSpan.FromSeconds(20);
            return c;
        }

        private TextBox _searchBox;
        private FlowLayoutPanel _flowPanel;
        private Card _searchPanel;
        private RoundButton _searchBtn;
        private Label _attribution;

        public ScriptHubPage()
        {
            Dock = DockStyle.Fill;
            BackColor = Theme.Bg;
            Visible = false;
            BuildUI();
            Resize += (s, e) => DoLayout();
        }

        private void BuildUI()
        {
            var title = new Label();
            title.Text = "Script Hub";
            title.Font = new Font("Segoe UI", 24, FontStyle.Bold);
            title.ForeColor = Theme.Text;
            title.Location = new Point(0, 0);
            title.AutoSize = true;
            Controls.Add(title);

            var subtitle = new Label();
            subtitle.Text = "Browse all scripts from ScriptBlox.";
            subtitle.Font = new Font("Segoe UI", 10);
            subtitle.ForeColor = Theme.Muted;
            subtitle.Location = new Point(3, 52);
            subtitle.AutoSize = true;
            Controls.Add(subtitle);

            _searchPanel = new Card();
            _searchPanel.Fill = Theme.Input;
            _searchPanel.Radius = 10;
            _searchPanel.Location = new Point(0, 90);
            _searchPanel.Size = new Size(700, 46);
            Controls.Add(_searchPanel);

            var searchIcon = new IconBox("search", 18, Theme.Muted);
            searchIcon.Location = new Point(16, 14);
            _searchPanel.Controls.Add(searchIcon);

            _searchBox = new TextBox();
            _searchBox.Location = new Point(46, 12);
            _searchBox.Size = new Size(540, 24);
            _searchBox.BackColor = Theme.Input;
            _searchBox.ForeColor = Theme.Text;
            _searchBox.Font = new Font("Segoe UI", 11);
            _searchBox.BorderStyle = BorderStyle.None;
            _searchBox.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    _ = LoadScriptsFromApi(_searchBox.Text);
                }
            };
            _searchPanel.Controls.Add(_searchBox);

            _searchBtn = new RoundButton();
            _searchBtn.Text = "Search";
            _searchBtn.Icon = "search";
            _searchBtn.IconSize = 14;
            _searchBtn.Location = new Point(588, 6);
            _searchBtn.Size = new Size(106, 34);
            _searchBtn.Normal = Theme.Accent;
            _searchBtn.Hover = Color.FromArgb(40, 190, 255);
            _searchBtn.Click += async (s, e) => await LoadScriptsFromApi(_searchBox.Text);
            _searchPanel.Controls.Add(_searchBtn);

            _flowPanel = new FlowLayoutPanel();
            _flowPanel.Location = new Point(0, 152);
            _flowPanel.Size = new Size(700, 376);
            _flowPanel.BackColor = Theme.Bg;
            _flowPanel.AutoScroll = true;
            _flowPanel.WrapContents = false;
            _flowPanel.FlowDirection = FlowDirection.TopDown;
            Controls.Add(_flowPanel);

            _attribution = new Label();
            _attribution.Text = "Powered by ScriptBlox.com";
            _attribution.Font = new Font("Segoe UI", 8);
            _attribution.ForeColor = Theme.Muted;
            _attribution.Location = new Point(3, 538);
            _attribution.AutoSize = true;
            Controls.Add(_attribution);
        }

        private void DoLayout()
        {
            int w = ClientSize.Width;
            int h = ClientSize.Height;
            if (w < 300 || h < 250) return;

            _searchPanel.Width = w;
            _searchBtn.Left = w - _searchBtn.Width - 6;
            _searchBox.Width = Math.Max(120, _searchBtn.Left - _searchBox.Left - 10);

            _flowPanel.Width = w;
            _flowPanel.Height = Math.Max(100, h - _flowPanel.Top - 26);
            _attribution.Top = h - 18;

            ResizeCards();
        }

        private void ResizeCards()
        {
            if (_flowPanel.ClientSize.Width <= 0) return;
            int cw = Math.Max(200, _flowPanel.ClientSize.Width - 22);
            foreach (Control c in _flowPanel.Controls)
            {
                c.Width = cw;
                var btn = c.Tag as Control;
                if (btn != null) btn.Left = cw - btn.Width - 14;
            }
        }

        public void EnsureLoaded()
        {
            if (_flowPanel.Controls.Count == 0)
                _ = LoadScriptsFromApi("");
        }

        private async Task LoadScriptsFromApi(string query)
        {
            int id = ++_loadId;
            try
            {
                string url = string.IsNullOrWhiteSpace(query)
                    ? "https://scriptblox.com/api/script/fetch?max=20"
                    : "https://scriptblox.com/api/script/search?q=" + Uri.EscapeDataString(query) + "&max=20";

                string json = await Http.GetStringAsync(url);
                if (id != _loadId) return;

                var scripts = ParseScripts(json);
                _flowPanel.Controls.Clear();

                if (scripts.Count == 0)
                {
                    if (OnLog != null) OnLog("No scripts found.");
                    return;
                }

                foreach (var s in scripts)
                    _flowPanel.Controls.Add(CreateScriptCard(s));

                ResizeCards();
                if (OnLog != null) OnLog(scripts.Count + " scripts loaded.");
            }
            catch (Exception ex)
            {
                if (OnLog != null) OnLog("ScriptBlox error: " + ex.Message);
            }
        }

        private List<ScriptInfo> ParseScripts(string json)
        {
            var list = new List<ScriptInfo>();
            var root = Json.Parse(json) as Dictionary<string, object>;
            var result = Json.Get(root, "result") as Dictionary<string, object>;
            var arr = Json.Get(result, "scripts") as List<object>;
            if (arr == null) return list;

            foreach (var item in arr)
            {
                var o = item as Dictionary<string, object>;
                if (o == null) continue;

                var info = new ScriptInfo();
                info.Title = Json.Str(o, "title");
                info.Slug = Json.Str(o, "slug");
                info.RawScript = Json.Str(o, "script");

                var game = Json.Get(o, "game") as Dictionary<string, object>;
                if (game != null)
                {
                    info.GameName = Json.Str(game, "name");
                    info.ImageUrl = Json.Str(game, "imageUrl");
                }
                if (string.IsNullOrEmpty(info.ImageUrl)) info.ImageUrl = Json.Str(o, "image");

                if (!string.IsNullOrEmpty(info.Title)) list.Add(info);
            }
            return list;
        }

        private Card CreateScriptCard(ScriptInfo info)
        {
            var card = new Card();
            card.Radius = 10;
            int cw = _flowPanel.ClientSize.Width > 0 ? Math.Max(200, _flowPanel.ClientSize.Width - 22) : 500;
            card.Size = new Size(cw, 110);
            card.Margin = new Padding(0, 0, 0, 10);

            var pic = new PictureBox();
            pic.Location = new Point(10, 10);
            pic.Size = new Size(90, 90);
            pic.BackColor = Theme.Input;
            pic.SizeMode = PictureBoxSizeMode.Zoom;
            pic.WaitOnLoad = false;
            if (!string.IsNullOrEmpty(info.ImageUrl))
            {
                string imgUrl = info.ImageUrl;
                if (imgUrl.StartsWith("/")) imgUrl = "https://scriptblox.com" + imgUrl;
                try { pic.LoadAsync(imgUrl); } catch { }
            }
            card.Controls.Add(pic);

            var titleLbl = new Label();
            titleLbl.Text = info.Title;
            titleLbl.Font = new Font("Segoe UI Semibold", 11);
            titleLbl.ForeColor = Theme.Text;
            titleLbl.BackColor = Color.Transparent;
            titleLbl.Location = new Point(112, 12);
            titleLbl.AutoSize = true;
            card.Controls.Add(titleLbl);

            var gameLbl = new Label();
            gameLbl.Text = string.IsNullOrEmpty(info.GameName) ? "Unknown Game" : info.GameName;
            gameLbl.Font = new Font("Segoe UI", 8.5f);
            gameLbl.ForeColor = Theme.Muted;
            gameLbl.BackColor = Color.Transparent;
            gameLbl.Location = new Point(112, 36);
            gameLbl.AutoSize = true;
            card.Controls.Add(gameLbl);

            var slugLbl = new Label();
            slugLbl.Text = "Slug: " + (info.Slug ?? "");
            slugLbl.Font = new Font("Consolas", 8);
            slugLbl.ForeColor = Theme.Muted;
            slugLbl.BackColor = Color.Transparent;
            slugLbl.Location = new Point(112, 56);
            slugLbl.AutoSize = true;
            card.Controls.Add(slugLbl);

            var loadBtn = new RoundButton();
            loadBtn.Text = "Load to Editor";
            loadBtn.Icon = "download";
            loadBtn.IconSize = 14;
            loadBtn.Size = new Size(144, 30);
            loadBtn.Location = new Point(card.Width - loadBtn.Width - 14, 70);
            loadBtn.Normal = Theme.Accent;
            loadBtn.Hover = Color.FromArgb(40, 190, 255);
            loadBtn.Font = new Font("Segoe UI Semibold", 9);
            loadBtn.Click += async (s, e) =>
            {
                try
                {
                    loadBtn.Enabled = false;
                    if (string.IsNullOrEmpty(info.RawScript) && !string.IsNullOrEmpty(info.Slug))
                    {
                        if (OnLog != null) OnLog("Loading script...");
                        string json = await Http.GetStringAsync("https://scriptblox.com/api/script/" + Uri.EscapeDataString(info.Slug));
                        var root = Json.Parse(json) as Dictionary<string, object>;
                        var res = Json.Get(root, "result") as Dictionary<string, object>;
                        var sc = Json.Get(res, "script") as Dictionary<string, object>;
                        info.RawScript = Json.Str(sc ?? res, "script");
                    }

                    if (!string.IsNullOrEmpty(info.RawScript) && OnLoadToEditor != null)
                        OnLoadToEditor(info.RawScript);
                    else if (OnLog != null)
                        OnLog("Script code is empty.");
                }
                catch (Exception ex)
                {
                    if (OnLog != null) OnLog("Load error: " + ex.Message);
                }
                finally { loadBtn.Enabled = true; }
            };
            card.Controls.Add(loadBtn);
            card.Tag = loadBtn;

            return card;
        }

        private class ScriptInfo
        {
            public string Title { get; set; }
            public string Slug { get; set; }
            public string GameName { get; set; }
            public string ImageUrl { get; set; }
            public string RawScript { get; set; }
        }
    }

    public partial class Form1 : Form
    {
        private const int HOTKEY_ID = 9000;
        private const int WM_HOTKEY = 0x0312;
        private const int VK_RSHIFT = 0xA1;

        private bool _attached = false;
        private bool _internalUiEnabled = false;
        private InternalUiForm _internalUi = null;

        private Panel sidebar;
        private Panel contentPanel;
        private RoundButton btnTabHome;
        private RoundButton btnTabEditor;
        private RoundButton btnTabScriptHub;
        private RoundButton btnTabSettings;
        private RoundButton btnAttach;
        private Label statusLabel;
        private Label homeStatusValue;

        private Panel homePage;
        private Panel editorPage;
        private Panel settingsPage;
        private ScriptHubPage scriptHubPage;

        private Card homeHero;
        private IconBox heroIcon;
        private Card homeQuick;
        private List<Card> homeCards = new List<Card>();

        private RichTextBox editor;
        private RichTextBox output;
        private RoundButton btnExecute;
        private RoundButton btnClear;
        private RoundButton btnOpen;
        private RoundButton btnSave;

        private ToggleSwitch chkAutoAttach;
        private ToggleSwitch chkVerbose;
        private ToggleSwitch chkInternalUi;
        private Label lblInternalStatus;

        private Timer robloxCheckTimer;

        public Form1()
        {
            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;
            InitializeComponent();
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.DarkTitleBar(Handle);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);

            Text = "Skid Menu";
            Size = new Size(1020, 650);
            MinimumSize = new Size(860, 560);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Bg;
            Font = new Font("Segoe UI", 9);
            DoubleBuffered = true;

            BuildContent();
            BuildSidebar();
            BuildHomePage();
            BuildEditorPage();
            BuildSettingsPage();
            BuildScriptHubPage();
            ShowHome();

            try { Native.RegisterHotKey(Handle, HOTKEY_ID, 0, VK_RSHIFT); }
            catch { Log("Hotkey registration failed."); }

            robloxCheckTimer = new Timer();
            robloxCheckTimer.Interval = 2000;
            robloxCheckTimer.Tick += RobloxCheckTimer_Tick;
            robloxCheckTimer.Start();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try { Native.UnregisterHotKey(Handle, HOTKEY_ID); } catch { }

            if (_internalUi != null && !_internalUi.IsDisposed)
            {
                _internalUi.Close();
                _internalUi = null;
            }

            base.OnFormClosing(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID)
                ToggleInternalUi();
            base.WndProc(ref m);
        }

        private void ToggleInternalUi()
        {
            if (!_attached || !_internalUiEnabled) return;

            if (_internalUi == null || _internalUi.IsDisposed)
            {
                _internalUi = new InternalUiForm();
                _internalUi.FormClosed += (s, e) => { _internalUi = null; };
                _internalUi.Show();
            }
            else if (_internalUi.Visible)
            {
                _internalUi.Hide();
            }
            else
            {
                _internalUi.Show();
                _internalUi.BringToFront();
            }
        }

        private Label MakeLabel(string text, Font font, Color color, int x, int y)
        {
            var l = new Label();
            l.Text = text;
            l.Font = font;
            l.ForeColor = color;
            l.Location = new Point(x, y);
            l.AutoSize = true;
            l.BackColor = Color.Transparent;
            return l;
        }

        private void BuildContent()
        {
            contentPanel = new Panel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.BackColor = Theme.Bg;
            contentPanel.Padding = new Padding(32, 28, 32, 24);
            Controls.Add(contentPanel);
        }

        private void BuildSidebar()
        {
            sidebar = new Panel();
            sidebar.Dock = DockStyle.Left;
            sidebar.Width = 224;
            sidebar.BackColor = Theme.Side;
            Controls.Add(sidebar);
            contentPanel.BringToFront();

            var border = new Panel();
            border.Dock = DockStyle.Right;
            border.Width = 1;
            border.BackColor = Theme.Border;
            sidebar.Controls.Add(border);

            var logoTile = new Card();
            logoTile.Radius = 10;
            logoTile.Fill = Theme.Accent;
            logoTile.GradientTo = Theme.Accent2;
            logoTile.Line = Color.Transparent;
            logoTile.Location = new Point(20, 20);
            logoTile.Size = new Size(40, 40);
            var logoText = new Label();
            logoText.Text = "S";
            logoText.Dock = DockStyle.Fill;
            logoText.TextAlign = ContentAlignment.MiddleCenter;
            logoText.ForeColor = Color.White;
            logoText.BackColor = Color.Transparent;
            logoText.Font = new Font("Segoe UI", 15, FontStyle.Bold);
            logoTile.Controls.Add(logoText);
            sidebar.Controls.Add(logoTile);

            sidebar.Controls.Add(MakeLabel("SKID MENU", new Font("Segoe UI", 13, FontStyle.Bold), Theme.Text, 70, 20));
            sidebar.Controls.Add(MakeLabel("Script Hub  \u00B7  v1.0.0", new Font("Segoe UI", 8), Theme.Muted, 72, 43));

            sidebar.Controls.Add(MakeLabel("MENU", new Font("Segoe UI", 7.5f, FontStyle.Bold), Color.FromArgb(90, 98, 112), 24, 92));

            btnTabHome = MakeNav("Home", "home", 116);
            btnTabEditor = MakeNav("Editor", "code", 160);
            btnTabScriptHub = MakeNav("Script Hub", "hub", 204);
            btnTabSettings = MakeNav("Settings", "sliders", 248);
            btnTabHome.Click += (s, ev) => ShowHome();
            btnTabEditor.Click += (s, ev) => ShowEditor();
            btnTabScriptHub.Click += (s, ev) => ShowScriptHub();
            btnTabSettings.Click += (s, ev) => ShowSettings();
            sidebar.Controls.Add(btnTabHome);
            sidebar.Controls.Add(btnTabEditor);
            sidebar.Controls.Add(btnTabScriptHub);
            sidebar.Controls.Add(btnTabSettings);

            var bottom = new Panel();
            bottom.Dock = DockStyle.Bottom;
            bottom.Height = 126;
            bottom.BackColor = Theme.Side;
            sidebar.Controls.Add(bottom);

            var statusCard = new Card();
            statusCard.Radius = 10;
            statusCard.Fill = Theme.Card;
            statusCard.Location = new Point(16, 8);
            statusCard.Size = new Size(192, 40);
            statusLabel = MakeLabel("\u25CF  Not attached", new Font("Segoe UI Semibold", 9), Theme.Red, 14, 11);
            statusCard.Controls.Add(statusLabel);
            bottom.Controls.Add(statusCard);

            btnAttach = new RoundButton();
            btnAttach.Text = "Attach";
            btnAttach.Icon = "bolt";
            btnAttach.IconSize = 16;
            btnAttach.Location = new Point(16, 62);
            btnAttach.Size = new Size(192, 46);
            btnAttach.Radius = 10;
            btnAttach.Normal = Theme.Accent;
            btnAttach.Hover = Color.FromArgb(40, 190, 255);
            btnAttach.Font = new Font("Segoe UI Semibold", 10);
            btnAttach.Click += (s, ev) => AttachToRoblox();
            bottom.Controls.Add(btnAttach);
        }

        private RoundButton MakeNav(string text, string icon, int top)
        {
            var b = new RoundButton();
            b.Text = text;
            b.Icon = icon;
            b.IconSize = 18;
            b.Location = new Point(16, top);
            b.Size = new Size(192, 40);
            b.Radius = 10;
            b.LeftAlign = true;
            b.Normal = Color.Transparent;
            b.Hover = Theme.Elevated;
            b.ForeColor = Theme.Muted;
            return b;
        }

        private Card MakeCard(string title, string value, Color valueColor, string icon, out Label valueLabel)
        {
            var card = new Card();
            card.Radius = 12;

            var badge = new Card();
            badge.Radius = 10;
            badge.Fill = Theme.AccentSoft;
            badge.Line = Color.Transparent;
            badge.Size = new Size(44, 44);
            badge.Location = new Point(16, 24);
            var ib = new IconBox(icon, 22, Theme.Accent);
            ib.Location = new Point(11, 11);
            badge.Controls.Add(ib);
            card.Controls.Add(badge);

            card.Controls.Add(MakeLabel(title.ToUpper(), new Font("Segoe UI", 8, FontStyle.Bold), Theme.Muted, 72, 24));
            valueLabel = MakeLabel(value, new Font("Segoe UI Semibold", 14), valueColor, 72, 44);
            card.Controls.Add(valueLabel);
            return card;
        }

        private void AddStep(Card parent, string num, string text, int y)
        {
            var circle = new Card();
            circle.Radius = 13;
            circle.Fill = Theme.AccentSoft;
            circle.Line = Color.Transparent;
            circle.Size = new Size(26, 26);
            circle.Location = new Point(22, y);
            var n = new Label();
            n.Text = num;
            n.Dock = DockStyle.Fill;
            n.TextAlign = ContentAlignment.MiddleCenter;
            n.ForeColor = Theme.Accent;
            n.BackColor = Color.Transparent;
            n.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            circle.Controls.Add(n);
            parent.Controls.Add(circle);

            parent.Controls.Add(MakeLabel(text, new Font("Segoe UI", 9.5f), Theme.Muted, 62, y + 3));
        }

        private void BuildHomePage()
        {
            homePage = new Panel();
            homePage.Dock = DockStyle.Fill;
            homePage.BackColor = Theme.Bg;
            homePage.Visible = false;
            contentPanel.Controls.Add(homePage);

            homeHero = new Card();
            homeHero.Radius = 14;
            homeHero.Fill = Color.FromArgb(24, 72, 112);
            homeHero.GradientTo = Theme.Card;
            homeHero.Line = Color.FromArgb(40, 90, 130);
            homeHero.Controls.Add(MakeLabel("Welcome back", new Font("Segoe UI", 22, FontStyle.Bold), Theme.Text, 26, 20));
            homeHero.Controls.Add(MakeLabel("Attach to Roblox, write your script and run it from the editor.", new Font("Segoe UI", 10), Color.FromArgb(170, 190, 215), 29, 66));
            heroIcon = new IconBox("bolt", 56, Color.FromArgb(90, Theme.Accent));
            homeHero.Controls.Add(heroIcon);
            homePage.Controls.Add(homeHero);

            Label v1, v2, v3;
            homeCards.Add(MakeCard("Connection", "Waiting", Theme.Yellow, "bolt", out v1));
            homeCards.Add(MakeCard("Version", "1.0.8", Theme.Text, "tag", out v2));
            homeCards.Add(MakeCard("Last updated", "2026-10-04", Theme.Text, "clock", out v3));
            homeStatusValue = v1;
            foreach (var c in homeCards) homePage.Controls.Add(c);

            homeQuick = new Card();
            homeQuick.Radius = 12;
            homeQuick.Controls.Add(MakeLabel("Quick start", new Font("Segoe UI Semibold", 11), Theme.Text, 22, 18));
            AddStep(homeQuick, "1", "Start Roblox and press Attach in the sidebar", 56);
            AddStep(homeQuick, "2", "Open the Editor tab and write or load a script", 92);
            AddStep(homeQuick, "3", "Press Execute, or enable the Internal UI and use RightShift", 128);
            homePage.Controls.Add(homeQuick);

            homePage.Resize += (s, e) => LayoutHome();
            LayoutHome();
        }

        private void LayoutHome()
        {
            if (homePage == null) return;
            int W = homePage.ClientSize.Width;
            if (W < 300) return;

            homeHero.SetBounds(0, 0, W, 112);
            heroIcon.Location = new Point(W - 96, 28);

            int gap = 16;
            int cw = (W - 2 * gap) / 3;
            for (int i = 0; i < homeCards.Count; i++)
                homeCards[i].SetBounds(i * (cw + gap), 128, cw, 92);

            homeQuick.SetBounds(0, 236, W, 176);
        }

        private void BuildEditorPage()
        {
            editorPage = new Panel();
            editorPage.Dock = DockStyle.Fill;
            editorPage.BackColor = Theme.Bg;
            editorPage.Visible = false;
            contentPanel.Controls.Add(editorPage);

            var editorCard = new Card();
            editorCard.Dock = DockStyle.Fill;
            editorCard.Fill = Theme.Input;
            editorCard.Radius = 12;
            editorCard.Padding = new Padding(16, 14, 16, 14);
            editorPage.Controls.Add(editorCard);

            editor = new RichTextBox();
            editor.Dock = DockStyle.Fill;
            editor.BackColor = Theme.Input;
            editor.ForeColor = Theme.Text;
            editor.Font = new Font("Consolas", 11);
            editor.BorderStyle = BorderStyle.None;
            editor.AcceptsTab = true;
            editor.WordWrap = false;
            editor.ScrollBars = RichTextBoxScrollBars.Both;
            editor.DetectUrls = false;
            editor.Text = "-- Roblox Script\nprint(\"Hello, Skid!\")\n";
            editor.TextChanged += (s, ev) => Highlighter.Apply(editor);
            editorCard.Controls.Add(editor);
            editor.HandleCreated += (s, ev) => Highlighter.Apply(editor);

            var gap = new Panel();
            gap.Dock = DockStyle.Bottom;
            gap.Height = 12;
            gap.BackColor = Theme.Bg;
            editorPage.Controls.Add(gap);

            var outCard = new Card();
            outCard.Dock = DockStyle.Bottom;
            outCard.Height = 156;
            outCard.Radius = 12;
            outCard.Padding = new Padding(14, 8, 14, 10);
            editorPage.Controls.Add(outCard);

            var outTitle = new Label();
            outTitle.Text = "OUTPUT";
            outTitle.Dock = DockStyle.Top;
            outTitle.Height = 24;
            outTitle.BackColor = Color.Transparent;
            outTitle.ForeColor = Theme.Muted;
            outTitle.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            outTitle.TextAlign = ContentAlignment.MiddleLeft;

            output = new RichTextBox();
            output.Dock = DockStyle.Fill;
            output.BackColor = Theme.Card;
            output.ForeColor = Theme.Green;
            output.Font = new Font("Consolas", 9.5f);
            output.ReadOnly = true;
            output.BorderStyle = BorderStyle.None;
            output.DetectUrls = false;
            outCard.Controls.Add(output);
            outCard.Controls.Add(outTitle);

            var toolbar = new Panel();
            toolbar.Dock = DockStyle.Top;
            toolbar.Height = 58;
            toolbar.BackColor = Theme.Bg;
            editorPage.Controls.Add(toolbar);

            btnExecute = MakeToolBtn("Execute", "play", 0, Color.FromArgb(40, 160, 92), Color.FromArgb(54, 188, 112));
            btnClear = MakeToolBtn("Clear", "trash", 124, Theme.Elevated, Color.FromArgb(44, 50, 63));
            btnOpen = MakeToolBtn("Open", "folder", 248, Theme.Elevated, Color.FromArgb(44, 50, 63));
            btnSave = MakeToolBtn("Save", "save", 372, Theme.Elevated, Color.FromArgb(44, 50, 63));

            btnExecute.Click += (s, ev) => ExecuteScript();
            btnClear.Click += (s, ev) => ClearEditor();
            btnOpen.Click += (s, ev) => OpenFile();
            btnSave.Click += (s, ev) => SaveFile();

            toolbar.Controls.Add(btnExecute);
            toolbar.Controls.Add(btnClear);
            toolbar.Controls.Add(btnOpen);
            toolbar.Controls.Add(btnSave);

            editorCard.BringToFront();
        }

        private RoundButton MakeToolBtn(string text, string icon, int left, Color normal, Color hover)
        {
            var b = new RoundButton();
            b.Text = text;
            b.Icon = icon;
            b.IconSize = 15;
            b.Location = new Point(left, 6);
            b.Size = new Size(116, 38);
            b.Radius = 10;
            b.Normal = normal;
            b.Hover = hover;
            return b;
        }

        private Card MakeSettingRow(string icon, string title, string desc, int y, out ToggleSwitch toggle)
        {
            var row = new Card();
            row.Radius = 12;
            row.Location = new Point(0, y);
            row.Size = new Size(640, 68);

            var ib = new IconBox(icon, 22, Theme.Accent);
            ib.Location = new Point(20, 23);
            row.Controls.Add(ib);

            row.Controls.Add(MakeLabel(title, new Font("Segoe UI Semibold", 10), Theme.Text, 58, 13));
            row.Controls.Add(MakeLabel(desc, new Font("Segoe UI", 8.5f), Theme.Muted, 58, 37));
            toggle = new ToggleSwitch();
            toggle.Location = new Point(row.Width - 66, 22);
            row.Controls.Add(toggle);
            return row;
        }

        private void BuildSettingsPage()
        {
            settingsPage = new Panel();
            settingsPage.Dock = DockStyle.Fill;
            settingsPage.BackColor = Theme.Bg;
            settingsPage.Visible = false;
            contentPanel.Controls.Add(settingsPage);

            settingsPage.Controls.Add(MakeLabel("Settings", new Font("Segoe UI", 24, FontStyle.Bold), Theme.Text, 0, 0));

            settingsPage.Controls.Add(MakeSettingRow("bolt", "Auto-Attach", "Attach automatically when Roblox is detected", 70, out chkAutoAttach));
            settingsPage.Controls.Add(MakeSettingRow("code", "Verbose logging", "Show detailed messages in the output panel", 148, out chkVerbose));
            chkVerbose.Checked = true;

            settingsPage.Controls.Add(MakeSettingRow("hub", "Internal UI", "In-game window, toggled with RightShift", 226, out chkInternalUi));
            chkInternalUi.Enabled = false;
            chkInternalUi.CheckedChanged += ChkInternalUi_CheckedChanged;

            lblInternalStatus = MakeLabel("Status: Not attached", new Font("Segoe UI", 9), Theme.Muted, 4, 308);
            settingsPage.Controls.Add(lblInternalStatus);

            var reset = new RoundButton();
            reset.Text = "Reset all settings";
            reset.Icon = "reset";
            reset.IconSize = 15;
            reset.Location = new Point(0, 346);
            reset.Size = new Size(186, 40);
            reset.Radius = 10;
            reset.Normal = Color.FromArgb(190, 52, 62);
            reset.Hover = Theme.Red;
            reset.Click += (s, ev) =>
            {
                chkAutoAttach.Checked = false;
                chkVerbose.Checked = true;
                chkInternalUi.Checked = false;
                MessageBox.Show("Settings reset.", "Skid Menu");
            };
            settingsPage.Controls.Add(reset);
        }

        private void BuildScriptHubPage()
        {
            scriptHubPage = new ScriptHubPage();
            scriptHubPage.OnLog = msg => Log(msg);
            scriptHubPage.OnLoadToEditor = code =>
            {
                editor.Text = code;
                ShowEditor();
                Log("Script loaded from Script Hub.");
            };
            contentPanel.Controls.Add(scriptHubPage);
        }

        private void ChkInternalUi_CheckedChanged(object sender, EventArgs e)
        {
            _internalUiEnabled = chkInternalUi.Checked;

            if (_internalUiEnabled)
            {
                lblInternalStatus.Text = "Status: Enabled - press RightShift in Roblox";
                lblInternalStatus.ForeColor = Theme.Green;
            }
            else
            {
                lblInternalStatus.Text = "Status: Disabled";
                lblInternalStatus.ForeColor = Theme.Muted;

                if (_internalUi != null && !_internalUi.IsDisposed)
                {
                    _internalUi.Close();
                    _internalUi = null;
                }
            }
        }

        private void ShowHome()
        {
            SetActiveTab(btnTabHome);
            homePage.Visible = true;
            editorPage.Visible = false;
            settingsPage.Visible = false;
            scriptHubPage.Visible = false;
        }

        private void ShowEditor()
        {
            SetActiveTab(btnTabEditor);
            homePage.Visible = false;
            editorPage.Visible = true;
            settingsPage.Visible = false;
            scriptHubPage.Visible = false;
        }

        private void ShowScriptHub()
        {
            SetActiveTab(btnTabScriptHub);
            homePage.Visible = false;
            editorPage.Visible = false;
            settingsPage.Visible = false;
            scriptHubPage.Visible = true;
            scriptHubPage.EnsureLoaded();
        }

        private void ShowSettings()
        {
            SetActiveTab(btnTabSettings);
            homePage.Visible = false;
            editorPage.Visible = false;
            settingsPage.Visible = true;
            scriptHubPage.Visible = false;
        }

        private void SetActiveTab(RoundButton active)
        {
            var tabs = new RoundButton[] { btnTabHome, btnTabEditor, btnTabScriptHub, btnTabSettings };
            foreach (var t in tabs)
            {
                t.Active = false;
                t.Normal = Color.Transparent;
                t.ForeColor = Theme.Muted;
                t.Invalidate();
            }
            active.Active = true;
            active.Normal = Theme.AccentSoft;
            active.ForeColor = Color.White;
            active.Invalidate();
        }

        private bool IsRobloxRunning()
        {
            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    if (p.ProcessName.IndexOf("RobloxPlayerBeta", StringComparison.OrdinalIgnoreCase) >= 0
                        || p.ProcessName.IndexOf("RobloxStudioBeta", StringComparison.OrdinalIgnoreCase) >= 0)
                        return true;
                }
                catch { }
            }
            return false;
        }

        private void RobloxCheckTimer_Tick(object sender, EventArgs e)
        {
            if (!_attached) return;
            if (!IsRobloxRunning()) Detach();
        }

        private void Detach()
        {
            _attached = false;
            statusLabel.Text = "\u25CF  Not attached";
            statusLabel.ForeColor = Theme.Red;
            homeStatusValue.Text = "Waiting";
            homeStatusValue.ForeColor = Theme.Yellow;
            Log("Roblox closed - detached.");

            if (_internalUi != null && !_internalUi.IsDisposed)
            {
                _internalUi.Close();
                _internalUi = null;
            }

            if (chkInternalUi != null)
            {
                chkInternalUi.Checked = false;
                chkInternalUi.Enabled = false;
            }

            if (lblInternalStatus != null)
            {
                lblInternalStatus.Text = "Status: Not attached";
                lblInternalStatus.ForeColor = Theme.Muted;
            }
        }

        private void AttachToRoblox()
        {
            if (_attached)
            {
                MessageBox.Show("Already attached.", "Skid Menu");
                return;
            }

            if (!IsRobloxRunning())
            {
                MessageBox.Show(
                    "Roblox is not running.\nPlease start Roblox first, then press Attach.",
                    "Skid Menu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            var terminal = new TerminalForm();
            terminal.Owner = this;
            terminal.Show();
        }

        public void OnAttached()
        {
            _attached = true;
            statusLabel.Text = "\u25CF  Attached";
            statusLabel.ForeColor = Theme.Green;
            homeStatusValue.Text = "Attached";
            homeStatusValue.ForeColor = Theme.Green;
            Log("Attached successfully.");

            if (chkInternalUi != null) chkInternalUi.Enabled = true;

            if (lblInternalStatus != null)
            {
                lblInternalStatus.Text = "Status: Attached - Internal UI available";
                lblInternalStatus.ForeColor = Theme.Green;
            }
        }

        private void ExecuteScript()
        {
            if (!_attached)
            {
                Log("Not attached to Roblox.");
                return;
            }

            string script = editor.Text;

            if (string.IsNullOrWhiteSpace(script))
            {
                Log("Editor is empty.");
                return;
            }

            int lineCount = script.Split('\n').Length;
            if (chkVerbose.Checked)
            {
                Log("Compiling script...");
                Log("Lines: " + lineCount + " | Chars: " + script.Length);
                Log("Sending to Roblox...");
            }

            try
            {
                bool ok = RobloxExecutor.Execute(script);
                if (ok)
                {
                    Log("Script executed successfully.");
                    ShowExecuteToast(script, lineCount);
                }
                else
                {
                    Log("Execute failed: pipe not connected.");
                }
            }
            catch (Exception ex)
            {
                Log("Execute error: " + ex.Message);
            }
        }

        private void ShowExecuteToast(string script, int lineCount)
        {
            string preview = script.Length > 60 ? script.Substring(0, 60) + "..." : script;
            preview = preview.Replace("\n", " ").Replace("\r", " ");
            new ExecuteToastForm(lineCount, preview).Show();
        }

        private void ClearEditor()
        {
            editor.Clear();
            Log("Editor cleared.");
        }

        private void OpenFile()
        {
            using (var ofd = new OpenFileDialog())
            {
                ofd.Filter = "Lua Files|*.lua|Text Files|*.txt|All Files|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        editor.Text = File.ReadAllText(ofd.FileName);
                        Log("Opened: " + ofd.FileName);
                    }
                    catch (Exception ex) { Log("Open error: " + ex.Message); }
                }
            }
        }

        private void SaveFile()
        {
            using (var sfd = new SaveFileDialog())
            {
                sfd.Filter = "Lua Files|*.lua|Text Files|*.txt|All Files|*.*";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllText(sfd.FileName, editor.Text);
                        Log("Saved: " + sfd.FileName);
                    }
                    catch (Exception ex) { Log("Save error: " + ex.Message); }
                }
            }
        }

        private void Log(string msg)
        {
            if (output == null || output.IsDisposed) return;
            output.SelectionStart = output.TextLength;
            output.SelectionColor = Theme.Muted;
            output.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] ");
            output.SelectionColor = Theme.Green;
            output.AppendText(msg + "\n");
            output.SelectionStart = output.TextLength;
            output.ScrollToCaret();
        }
    }

    public class TerminalForm : Form
    {
        private RichTextBox console;
        private Timer countdownTimer;
        private int secondsLeft = 6;

        public TerminalForm()
        {
            Text = "Skid Menu Injector";
            Size = new Size(540, 380);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Input;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Padding = new Padding(12);

            console = new RichTextBox();
            console.Dock = DockStyle.Fill;
            console.BackColor = Theme.Input;
            console.ForeColor = Theme.Green;
            console.Font = new Font("Consolas", 9.5f);
            console.ReadOnly = true;
            console.BorderStyle = BorderStyle.None;
            console.DetectUrls = false;
            Controls.Add(console);

            Load += TerminalForm_Load;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.DarkTitleBar(Handle);
        }

        private void TerminalForm_Load(object sender, EventArgs e)
        {
            Print("Skid Menu Injector v1.0.0");
            Print("------------------------------");
            Print("");
            Print("[*] Scanning for Roblox process...");
            Print("[+] Found RobloxPlayerBeta.exe");
            Print("[*] Preparing injection...");
            Print("[*] Allocating memory in target process...");
            Print("[+] Memory allocated at 0x7FF6A4C20000");
            Print("[*] Writing payload...");
            Print("[+] Payload written (48,392 bytes)");
            Print("[*] Creating remote thread...");
            Print("[+] Thread created");
            Print("");
            Print("[*] Waiting for initialization...");
            Print("");

            countdownTimer = new Timer();
            countdownTimer.Interval = 1000;
            countdownTimer.Tick += CountdownTimer_Tick;
            countdownTimer.Start();
        }

        private void CountdownTimer_Tick(object sender, EventArgs e)
        {
            secondsLeft--;
            Print("[*] Initializing... " + secondsLeft + "s");

            if (secondsLeft <= 0)
            {
                countdownTimer.Stop();
                Print("");
                Print("==============================");
                Print("  Skid Menu Injected Successfully");
                Print("==============================");
                Print("");
                Print("[+] TP Handler loaded");
                Print("[+] RakNet Library loaded");
                Print("[+] Script executor ready");
                Print("[+] UI hooks installed");

                if (Owner is Form1 main)
                    main.OnAttached();

                Timer closeTimer = new Timer();
                closeTimer.Interval = 800;
                closeTimer.Tick += (cs, ce) =>
                {
                    closeTimer.Stop();
                    closeTimer.Dispose();
                    Close();
                    new RobloxOverlayForm().Show();
                };
                closeTimer.Start();
            }
        }

        private void Print(string text)
        {
            console.AppendText(text + "\n");
            console.SelectionStart = console.TextLength;
            console.ScrollToCaret();
        }
    }

    public class RobloxOverlayForm : Form
    {
        private RichTextBox messages;
        private Timer addTimer;
        private int messageIndex = 0;

        private readonly string[] lines = new string[]
        {
            "[SKID MENU] Injected Successfully",
            "[SKID MENU] RakNet Library loaded",
            "[SKID MENU] TP Handler loaded",
            "[SKID MENU] Script executor ready",
            "[SKID MENU] Press RightShift for Internal UI"
        };

        public RobloxOverlayForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = Theme.Bg;
            Opacity = 0.88;
            StartPosition = FormStartPosition.Manual;
            Padding = new Padding(16, 10, 16, 10);

            messages = new RichTextBox();
            messages.Dock = DockStyle.Fill;
            messages.BackColor = Theme.Bg;
            messages.ForeColor = Theme.Accent;
            messages.Font = new Font("Consolas", 10.5f);
            messages.ReadOnly = true;
            messages.BorderStyle = BorderStyle.None;
            messages.ScrollBars = RichTextBoxScrollBars.None;
            messages.DetectUrls = false;
            Controls.Add(messages);

            Load += RobloxOverlayForm_Load;
        }

        private void RobloxOverlayForm_Load(object sender, EventArgs e)
        {
            PositionOverRoblox();

            addTimer = new Timer();
            addTimer.Interval = 400;
            addTimer.Tick += AddTimer_Tick;
            addTimer.Start();

            Timer closeTimer = new Timer();
            closeTimer.Interval = 5000;
            closeTimer.Tick += (cs, ce) =>
            {
                closeTimer.Stop();
                closeTimer.Dispose();
                Close();
            };
            closeTimer.Start();
        }

        private void PositionOverRoblox()
        {
            Native.RECT r;
            if (Native.GetRobloxRect(out r))
            {
                Width = r.Right - r.Left;
                Height = 150;
                Left = r.Left;
                Top = r.Bottom - Height;
                return;
            }

            var screen = Screen.PrimaryScreen.WorkingArea;
            Width = screen.Width;
            Height = 150;
            Left = screen.Left;
            Top = screen.Bottom - 150;
        }

        private void AddTimer_Tick(object sender, EventArgs e)
        {
            if (messageIndex >= lines.Length)
            {
                addTimer.Stop();
                return;
            }

            messages.AppendText(lines[messageIndex] + "\n");
            messages.SelectionStart = messages.TextLength;
            messages.ScrollToCaret();
            messageIndex++;
        }
    }

    public class ExecuteToastForm : Form
    {
        private readonly int _lines;
        private readonly string _preview;

        public ExecuteToastForm(int lines, string preview)
        {
            _lines = lines;
            _preview = preview;

            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = Theme.Card;
            Opacity = 0.95;
            StartPosition = FormStartPosition.Manual;
            Size = new Size(400, 92);
            using (var path = Native.Round(new Rectangle(0, 0, Width, Height), 10))
                Region = new Region(path);

            Load += ExecuteToastForm_Load;
        }

        private void ExecuteToastForm_Load(object sender, EventArgs e)
        {
            Native.RECT r;
            if (Native.GetRobloxRect(out r))
            {
                Left = r.Left + 20;
                Top = r.Top + 20;
            }
            else
            {
                var screen = Screen.PrimaryScreen.WorkingArea;
                Left = screen.Left + 20;
                Top = screen.Top + 20;
            }

            var strip = new Panel();
            strip.Dock = DockStyle.Left;
            strip.Width = 5;
            strip.BackColor = Theme.Green;
            Controls.Add(strip);

            Label title = new Label();
            title.Text = "Script executed";
            title.Font = new Font("Segoe UI Semibold", 10);
            title.ForeColor = Theme.Text;
            title.Location = new Point(18, 10);
            title.AutoSize = true;
            Controls.Add(title);

            Label meta = new Label();
            meta.Text = _lines + " lines  \u00B7  no errors";
            meta.Font = new Font("Segoe UI", 8.5f);
            meta.ForeColor = Theme.Green;
            meta.Location = new Point(18, 34);
            meta.AutoSize = true;
            Controls.Add(meta);

            Label prev = new Label();
            prev.Text = _preview;
            prev.Font = new Font("Consolas", 8.5f);
            prev.ForeColor = Theme.Muted;
            prev.AutoSize = false;
            prev.Size = new Size(370, 32);
            prev.Location = new Point(18, 56);
            Controls.Add(prev);

            Timer closeTimer = new Timer();
            closeTimer.Interval = 3500;
            closeTimer.Tick += (cs, ce) =>
            {
                closeTimer.Stop();
                closeTimer.Dispose();
                Close();
            };
            closeTimer.Start();
        }
    }

    public class InternalUiForm : Form
    {
        private RoundButton btnTabEditor;
        private RoundButton btnTabSettings;
        private Panel contentPanel;
        private Panel editorPage;
        private Panel settingsPage;
        private RichTextBox editorBox;
        private RichTextBox consoleBox;
        private ToggleSwitch chkRakNet;
        private ToggleSwitch chkAutoExecute;

        public InternalUiForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            Size = new Size(620, 500);
            BackColor = Theme.Bg;
            TopMost = true;
            ShowInTaskbar = false;
            Opacity = 0.97;
            StartPosition = FormStartPosition.Manual;
            DoubleBuffered = true;
            Font = new Font("Segoe UI", 9);
            using (var path = Native.Round(new Rectangle(0, 0, Width, Height), 12))
                Region = new Region(path);

            PositionOverRoblox();

            BuildHeader();
            BuildTabBar();
            BuildContent();
            BuildEditorTab();
            BuildSettingsTab();
            ShowEditorTab();
        }

        private void PositionOverRoblox()
        {
            Native.RECT r;
            if (Native.GetRobloxRect(out r))
            {
                int w = r.Right - r.Left;
                Left = r.Left + (w / 2) - (Width / 2);
                Top = r.Top + 90;
                return;
            }

            var screen = Screen.PrimaryScreen.WorkingArea;
            Left = screen.Left + (screen.Width / 2) - (Width / 2);
            Top = screen.Top + 110;
        }

        private Label Lbl(string text, Font font, Color color, int x, int y)
        {
            var l = new Label();
            l.Text = text;
            l.Font = font;
            l.ForeColor = color;
            l.Location = new Point(x, y);
            l.AutoSize = true;
            l.BackColor = Color.Transparent;
            return l;
        }

        private void BuildHeader()
        {
            var header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 44;
            header.BackColor = Theme.Side;
            header.MouseDown += Header_MouseDown;
            Controls.Add(header);

            var accent = new Panel();
            accent.Dock = DockStyle.Bottom;
            accent.Height = 2;
            accent.BackColor = Theme.Accent;
            header.Controls.Add(accent);

            var title = Lbl("SKID MENU", new Font("Segoe UI", 10, FontStyle.Bold), Theme.Text, 16, 12);
            title.MouseDown += Header_MouseDown;
            header.Controls.Add(title);

            var conn = Lbl("\u25CF Connected", new Font("Segoe UI", 8, FontStyle.Bold), Theme.Green, 112, 15);
            conn.MouseDown += Header_MouseDown;
            header.Controls.Add(conn);

            var hint = Lbl("RightShift to toggle", new Font("Segoe UI", 8), Theme.Muted, Width - 190, 15);
            hint.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            hint.MouseDown += Header_MouseDown;
            header.Controls.Add(hint);

            var closeBtn = new Button();
            closeBtn.Text = "\u2715";
            closeBtn.Dock = DockStyle.Right;
            closeBtn.Width = 46;
            closeBtn.FlatStyle = FlatStyle.Flat;
            closeBtn.FlatAppearance.BorderSize = 0;
            closeBtn.ForeColor = Theme.Muted;
            closeBtn.BackColor = Theme.Side;
            closeBtn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            closeBtn.Cursor = Cursors.Hand;
            closeBtn.Click += (s, e) => Hide();
            closeBtn.MouseEnter += (s, e) => { closeBtn.BackColor = Theme.Red; closeBtn.ForeColor = Color.White; };
            closeBtn.MouseLeave += (s, e) => { closeBtn.BackColor = Theme.Side; closeBtn.ForeColor = Theme.Muted; };
            header.Controls.Add(closeBtn);
        }

        private void Header_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Native.ReleaseCapture();
                Native.SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }

        private void BuildTabBar()
        {
            var tabBar = new Panel();
            tabBar.Dock = DockStyle.Top;
            tabBar.Height = 50;
            tabBar.BackColor = Theme.Side;
            Controls.Add(tabBar);

            var line = new Panel();
            line.Dock = DockStyle.Bottom;
            line.Height = 1;
            line.BackColor = Theme.Border;
            tabBar.Controls.Add(line);

            btnTabEditor = MakeTabButton("Editor", "code", 14);
            btnTabEditor.Click += (s, e) => ShowEditorTab();
            tabBar.Controls.Add(btnTabEditor);

            btnTabSettings = MakeTabButton("Settings", "sliders", 132);
            btnTabSettings.Click += (s, e) => ShowSettingsTab();
            tabBar.Controls.Add(btnTabSettings);
        }

        private RoundButton MakeTabButton(string text, string icon, int left)
        {
            var b = new RoundButton();
            b.Text = text;
            b.Icon = icon;
            b.IconSize = 15;
            b.Location = new Point(left, 8);
            b.Size = new Size(108, 34);
            b.Radius = 10;
            b.Normal = Theme.Elevated;
            b.ForeColor = Theme.Muted;
            return b;
        }

        private void BuildContent()
        {
            contentPanel = new Panel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.BackColor = Theme.Bg;
            contentPanel.Padding = new Padding(14);
            Controls.Add(contentPanel);
            contentPanel.BringToFront();
        }

        private void BuildEditorTab()
        {
            editorPage = new Panel();
            editorPage.Dock = DockStyle.Fill;
            editorPage.BackColor = Theme.Bg;
            editorPage.Visible = false;
            contentPanel.Controls.Add(editorPage);

            var editorCard = new Card();
            editorCard.Dock = DockStyle.Fill;
            editorCard.Fill = Theme.Input;
            editorCard.Radius = 10;
            editorCard.Padding = new Padding(12, 10, 12, 10);
            editorPage.Controls.Add(editorCard);

            editorBox = new RichTextBox();
            editorBox.Dock = DockStyle.Fill;
            editorBox.BackColor = Theme.Input;
            editorBox.ForeColor = Theme.Text;
            editorBox.Font = new Font("Consolas", 10.5f);
            editorBox.BorderStyle = BorderStyle.None;
            editorBox.AcceptsTab = true;
            editorBox.WordWrap = false;
            editorBox.ScrollBars = RichTextBoxScrollBars.Both;
            editorBox.DetectUrls = false;
            editorBox.Text = "-- Internal Script\nprint(\"Internal UI loaded\")\n";
            editorBox.TextChanged += (s, e) => Highlighter.Apply(editorBox);
            editorCard.Controls.Add(editorBox);
            editorBox.HandleCreated += (s, e) => Highlighter.Apply(editorBox);

            var gap = new Panel();
            gap.Dock = DockStyle.Bottom;
            gap.Height = 10;
            gap.BackColor = Theme.Bg;
            editorPage.Controls.Add(gap);

            var consoleCard = new Card();
            consoleCard.Dock = DockStyle.Bottom;
            consoleCard.Height = 120;
            consoleCard.Radius = 10;
            consoleCard.Padding = new Padding(12, 10, 12, 10);
            editorPage.Controls.Add(consoleCard);

            consoleBox = new RichTextBox();
            consoleBox.Dock = DockStyle.Fill;
            consoleBox.BackColor = Theme.Card;
            consoleBox.ForeColor = Theme.Green;
            consoleBox.Font = new Font("Consolas", 9);
            consoleBox.ReadOnly = true;
            consoleBox.BorderStyle = BorderStyle.None;
            consoleBox.DetectUrls = false;
            consoleBox.Text = "[Internal] Ready\n";
            consoleCard.Controls.Add(consoleBox);

            var toolbar = new Panel();
            toolbar.Dock = DockStyle.Top;
            toolbar.Height = 48;
            toolbar.BackColor = Theme.Bg;
            editorPage.Controls.Add(toolbar);

            var run = new RoundButton();
            run.Text = "Execute";
            run.Icon = "play";
            run.IconSize = 14;
            run.Location = new Point(0, 4);
            run.Size = new Size(112, 34);
            run.Radius = 10;
            run.Normal = Color.FromArgb(40, 160, 92);
            run.Hover = Color.FromArgb(54, 188, 112);
            run.Click += (s, e) => InternalExecute();
            toolbar.Controls.Add(run);

            var clr = new RoundButton();
            clr.Text = "Clear";
            clr.Icon = "trash";
            clr.IconSize = 14;
            clr.Location = new Point(120, 4);
            clr.Size = new Size(112, 34);
            clr.Radius = 10;
            clr.Click += (s, e) =>
            {
                editorBox.Clear();
                InternalLog("Editor cleared.");
            };
            toolbar.Controls.Add(clr);

            editorCard.BringToFront();
        }

        private void BuildSettingsTab()
        {
            settingsPage = new Panel();
            settingsPage.Dock = DockStyle.Fill;
            settingsPage.BackColor = Theme.Bg;
            settingsPage.Visible = false;
            contentPanel.Controls.Add(settingsPage);

            settingsPage.Controls.Add(Lbl("Internal Settings", new Font("Segoe UI", 15, FontStyle.Bold), Theme.Text, 0, 0));

            chkRakNet = AddRow("hub", "RakNet Library", "Enable networking layer", 50, true);
            chkAutoExecute = AddRow("play", "Auto-Execute", "Run the editor script on injection", 122, false);

            var info = new Card();
            info.Radius = 10;
            info.Location = new Point(0, 200);
            info.Size = new Size(560, 90);
            info.Controls.Add(Lbl("STATUS", new Font("Segoe UI", 8, FontStyle.Bold), Theme.Muted, 16, 12));
            info.Controls.Add(Lbl("RakNet Library:  Loaded\nVersion:                1.0.0\nStatus:                 Active", new Font("Consolas", 9), Theme.Green, 16, 34));
            settingsPage.Controls.Add(info);
        }

        private ToggleSwitch AddRow(string icon, string title, string desc, int y, bool on)
        {
            var row = new Card();
            row.Radius = 10;
            row.Location = new Point(0, y);
            row.Size = new Size(560, 62);

            var ib = new IconBox(icon, 20, Theme.Accent);
            ib.Location = new Point(16, 21);
            row.Controls.Add(ib);

            row.Controls.Add(Lbl(title, new Font("Segoe UI Semibold", 10), Theme.Text, 50, 10));
            row.Controls.Add(Lbl(desc, new Font("Segoe UI", 8.5f), Theme.Muted, 50, 34));
            var t = new ToggleSwitch();
            t.Location = new Point(row.Width - 62, 19);
            row.Controls.Add(t);
            t.Checked = on;
            settingsPage.Controls.Add(row);
            return t;
        }

        private void SetTab(RoundButton active, RoundButton other)
        {
            active.Active = true;
            active.Normal = Theme.AccentSoft;
            active.ForeColor = Color.White;
            other.Active = false;
            other.Normal = Theme.Elevated;
            other.ForeColor = Theme.Muted;
            active.Invalidate();
            other.Invalidate();
        }

        private void ShowEditorTab()
        {
            editorPage.Visible = true;
            settingsPage.Visible = false;
            SetTab(btnTabEditor, btnTabSettings);
        }

        private void ShowSettingsTab()
        {
            editorPage.Visible = false;
            settingsPage.Visible = true;
            SetTab(btnTabSettings, btnTabEditor);
        }

        private void InternalExecute()
        {
            string script = editorBox.Text;
            if (string.IsNullOrWhiteSpace(script))
            {
                InternalLog("Script is empty.");
                return;
            }

            InternalLog("Compiling (" + script.Length + " chars)...");
            InternalLog("Sending to RakNet channel...");

            bool ok = RobloxExecutor.Execute(script);
            if (ok)
                InternalLog("Executed successfully.");
            else
                InternalLog("Execute failed: pipe not connected.");
        }

        private void InternalLog(string msg)
        {
            if (consoleBox == null || consoleBox.IsDisposed) return;
            consoleBox.AppendText("[Internal] " + msg + "\n");
            consoleBox.SelectionStart = consoleBox.TextLength;
            consoleBox.ScrollToCaret();
        }
    }
}